/**
 * You can also use following 4 parameters for 'requestDated' and 'requestRanges' methods
 * 'categoryCode' property is used as a shortcut, making them all insignificant
 *
 * For example
 *
 * sourceCode: Rates.state.converterParams.sourceCode,
 * destinationCode: Rates.state.converterParams.destinationCode,
 * exchangeType: Rates.state.converterParams.exchangeType,
 * servicePack: Rates.state.converterParams.servicePack
 *
 */
import urls from './urls';

const { tools } = SBT.TOOLBOX;
const { _, moment } = window;

// Формат времени используемый в попапе графика.
const HIGHLIGHT_ACTIVE_FROM_DATE_FORMAT = 'DD.MM.YYYY HH:mm';

export default function(Rates) {
    return {
        /**
         * Получить описательные поля валют или металлов.
         */
        requestInfo() {
            const { mode, language, codes } = Rates.props;

            $.ajax({
                url: tools.concatPipedURL(urls.info, {
                    type: mode === 'metal' ? 'METAL' : 'CURRENCY',
                }),
                error() {
                    Rates.setState({
                        error: {
                            ...Rates.state.error,
                            info: true,
                        },
                    });
                },
                success(currencies) {
                    if (!currencies.length) {
                        return;
                    }

                    const data = { ...Rates.state.data };
                    const nameProp = `currencyName${language === 'en' ? 'En' : ''}`;
                    const currentRegion = SBT.TOOLBOX.tools.getRegion();
                    currencies.forEach((currency, order) => {
                        const { currencyCode } = currency;

                        // Оставляем только валюты доступные в текщем регионе.
                        if (
                            // Такого не должно быть. Но на случай, если изменится формат, лучше оставлю.
                            currency.accessRegion != null &&
                            !currency.accessRegion.split(',').includes(currentRegion)
                        ) {
                            return;
                        }

                        const display = !!codes[currencyCode];
                        const checked = display && !!codes[currencyCode].checked;
                        data[currencyCode] = Object.assign(data[currencyCode] || {}, {
                            order,
                            display,
                            checked,
                            name: currency[nameProp],
                            isoName: currency.isoCur,
                        });
                    });

                    Rates.setState({ data });
                },
            });
        },

        requestCurrent() {
            const checkedCodes = Rates.utils.getCodes('checked');

            const params = {
                regionId: Rates.props.regionId,
                rateCategory: Rates.state.ratesType,
                currencyCode: checkedCodes,
            };

            if (_.isEqual(Rates.state.cachedParams.current, params)) {
                return;
            }

            const currentProp = 'ratesCurrent';
            const currentPropFull = currentProp + 'Full';

            const emptyRates = {
                0: {
                    buyValue: '\u2014',
                    sellValue: '\u2014',
                    buyChange: '\u2014',
                    sellChange: '\u2014',
                    scale: '\u2014',
                },
            };

            const data = { ...Rates.state.data };

            checkedCodes.forEach(code => {
                // no conflict with data setting requests
                if (!data[code]) {
                    data[code] = {};
                }
                data[code][currentPropFull] = { ...emptyRates };

                Object.defineProperty(data[code], currentProp, {
                    configurable: true,
                    get() {
                        // using 0 if the field is empty
                        const amount = parseInt(Rates.state.converterAmount, 10) || 0;
                        const limits = Object.keys(this[currentPropFull])
                            .map(el => parseInt(el, 10))
                            .sort((a, b) => a - b);

                        let limit;
                        for (let i = 0; i < limits.length; i++) {
                            const next = limits[i + 1];
                            if (typeof next !== 'undefined') {
                                if (amount < next) {
                                    limit = limits[i];
                                    break;
                                }
                            } else {
                                limit = limits[i];
                            }
                        }
                        return this[currentPropFull][limit];
                    },
                });
            });

            Rates.setState({ data });

            $.ajax({
                url: tools.concatPipedURL(urls.current, params),
                success(response) {
                    let latestChange = 0;

                    const data = { ...Rates.state.data };

                    checkedCodes.forEach(code => {
                        const item = response[Rates.state.ratesType][code];

                        // no conflict with data setting requests
                        if (!data[code]) {
                            data[code] = {};
                        }

                        if (item) {
                            data[code][currentPropFull] = {};
                            Object.keys(item).forEach(l => {

                                data[code][currentPropFull][l] = {
                                    buyValue: item[l].buyValue,
                                    sellValue: item[l].sellValue,
                                    buyChange: item[l].buyValue - item[l].buyValuePrev,
                                    sellChange: item[l].sellValue - item[l].sellValuePrev,
                                    scale: item[l].scale,
                                };

                                if (item[l].activeFrom > latestChange) {
                                    latestChange = item[l].activeFrom;
                                }
                            });
                        } else {
                            data[code][currentPropFull] = { ...emptyRates };
                        }
                    });

                    Rates.setState({
                        data,
                        ratesCurrentLatestChange: latestChange,
                        cachedParams: {
                            ...Rates.state.cachedParams,
                            current: params,
                        },
                    });
                },
            });
        },

        requestRanges() {
            const requestCodes = Rates.utils.getCodes('checked');
            const params = {
                regionId: Rates.props.regionId,
                currencyCode: requestCodes,
                categoryCode: Rates.state.ratesType,
            };

            if (_.isEqual(Rates.state.cachedParams.ranges, params)) {
                Rates.onRangesLoaded();
                return;
            }

            $.ajax({
                url: tools.concatPipedURL(urls.ranges, params),
                error(xhr) {
                    Rates.utils.log('warn', 'ajax error. %d: %s',
                        xhr.status,
                        xhr.responseJSON
                        ? (xhr.responseJSON.message || 'Empty message')
                        : (xhr.responseText || 'No text. Check URL or connection')
                    );
                },
                success(response) {
                    const newStateData = { ...Rates.state.data };

                    requestCodes.forEach(code => {
                        // no conflict with data setting requests
                        if (!newStateData[code]) {
                            newStateData[code] = {};
                        }

                        const item = response[code];
                        if (item) {
                            if (item.length > 0) {
                                item.forEach((el, i) => {
                                    el.checked = i === 0;
                                });
                                newStateData[code].ranges = item;
                            } else {
                                Rates.utils.log('warn', 'empty ranges array received for code: %s.', code);
                            }
                        } else {
                            Rates.utils.log('warn', 'no ranges received for code: %s.', code);
                        }
                        newStateData[code].rangesVisible = false;
                    });

                    Rates.setState({
                        data: newStateData,
                        cachedParams: {
                            ...Rates.state.cachedParams,
                            ranges: params,
                        },
                    });
                    Rates.onRangesLoaded();
                },
            });
        },

        requestDated() {
            const postBody = {
                currencyData: [],
                categoryCode: Rates.state.ratesType,
            };

            Rates.utils.getCodes('checked').forEach(code => {
                // if a code doesn't have a range, skip it
                if (!Rates.state.data[code].ranges) {
                    const newStateData = { ...Rates.state.data };
                    newStateData[code].ratesDated = 'NODATA';
                    Rates.setState({ data: newStateData });
                    return;
                }
                postBody.currencyData.push({
                    currencyCode: code,
                    rangesAmountFrom: (
                        Rates.state.data[code].ranges
                            .map(range => range.amountFrom)
                            .sort((amount1, amount2) => amount1 - amount2)
                    ),
                });
            });

            if (!postBody.currencyData.length) {
                Rates.utils.getCodes('ratesDated').forEach(code => {
                    if (!Rates.state.data[code].checked) {
                        const newStateData = { ...Rates.state.data };
                        newStateData[code].ratesDated = null;
                        Rates.setState({ data: newStateData });
                    }
                });
                return;
            }

            const params = {
                regionId: Rates.props.regionId,
                fromDate: Rates.state.fromDate,
                toDate: Rates.state.toDate,
            };

            $.ajax({
                type: 'POST',
                data: JSON.stringify(postBody),
                contentType: 'application/json',
                url: tools.concatPipedURL(urls.rates, params),
                error(xhr) {
                    Rates.utils.log('warn', 'ajax error. %d: %s',
                        xhr.status,
                        xhr.responseJSON
                        ? (xhr.responseJSON.message || 'Empty message')
                        : (xhr.responseText || 'No text. Check URL or connection')
                    );
                },
                success(response) {
                    const newStateData = { ...Rates.state.data };

                    // no conflicts should happen here, this request shouldn't be initial

                    Object.keys(Rates.state.data).forEach(code => {
                        const newItem = newStateData[code];
                        if (response[code]) {
                            if (response[code].rates) {
                                newItem.ratesDated = response[code].rates;
                                newItem.scale = response[code].scale;
                                // in case of no info has been received yet, showing the code instead
                                newItem.name = newItem.name || code;
                            } else {
                                if (!newItem.checked) {
                                    newItem.ratesDated = null;
                                    newItem.scale = '\u2014';
                                    newItem.name = newItem.name || code;
                                }
                                Rates.utils.log('warn', 'No dated rates received for code: %s.', code);
                            }
                            // same check as before sending ajax, if it's checked, don't remove it
                        } else if (!newItem.checked) {
                            newItem.ratesDated = null;
                            newItem.scale = '\u2014';
                            newItem.name = newItem.name || code;
                        }
                    });

                    Rates.setState({
                        data: newStateData,
                        cachedParams: {
                            ...Rates.state.cachedParams,
                            dated: params,
                            datedBody: postBody,
                        },
                    });
                    Rates.onDatedLoaded();
                },
            });
        },

        requestConversion() {
            const { regionId } = Rates.props;
            const {
                converterParams,
                converterFrom,
                converterTo,
                converterAmount,
                converterDateSelect,
                converterDate,
            } = Rates.state;

            const params = {
                regionId,
                sourceCode: converterParams.sourceCode,
                destinationCode: converterParams.destinationCode,
                exchangeType: converterParams.exchangeType,
                servicePack: converterParams.servicePack,
                fromCurrencyCode: converterFrom, // ok if an empty string
                toCurrencyCode: converterTo, // ok if an empty string
                amount: (
                    converterAmount
                        .replace(Rates.utils.regExp.commas, '.')
                        .replace(Rates.utils.regExp.spaces, '')
                ),
            };

            if (converterDateSelect === 'select') {
                params.date = `${converterDate}:00`;
            }

            if (_.isEqual(Rates.state.cachedParams.converter, params)) {
                Rates.updateConverterResult();
                return;
            }

            $.ajax({
                url: tools.concatPipedURL(urls.convert, params),
                success(result) {
                    if (result) {
                        Rates.setState({
                            converterResult: {
                                from: converterFrom,
                                to: converterTo,
                                amount: converterAmount,
                                value: result.amount,
                                crossRate: result.crossRate,
                                valid: true,
                            },
                            cachedParams: {
                                ...Rates.state.cachedParams,
                                converter: params,
                            },
                        });
                    } else {
                        Rates.setState({
                            converterResult: {
                                ...Rates.state.converterResult,
                                valid: false,
                            },
                        });
                    }
                    Rates.updateConverterResult();
                },
            });
        },

        drawPlot(codes) {
            codes.forEach(function(code) {
                const plot = {
                    values: {
                        max: {
                            buy: Number.MIN_VALUE,
                            sell: Number.MIN_VALUE,
                            period: Number.MIN_VALUE,
                        },
                        min: {
                            buy: Number.MAX_VALUE,
                            sell: Number.MAX_VALUE,
                            period: Number.MAX_VALUE,
                        },
                        fill(prop, value) {
                            if (value > plot.values.max[prop]) {
                                plot.values.max[prop] = value;
                            }
                            if (value < plot.values.min[prop]) {
                                plot.values.min[prop] = value;
                            }
                        },
                    },

                    getTooltip(type, [activeFrom, value]) {
                        return `
                            <div class="plot-tooltip">
                                <h3>${Rates.props.dict[`current${Rates.utils.capitalize(type)}`]}</h3>
                                <p>
                                    ${moment(activeFrom).format(HIGHLIGHT_ACTIVE_FROM_DATE_FORMAT)}:
                                    <em>
                                        ${Rates.utils.format(value)}
                                        ${Rates.props.destinationCurrencyShort}
                                    </em>
                                </p>
                                <p>
                                    ${Rates.props.dict.plotMax}
                                    <em>
                                        ${Rates.utils.format(this.values.max[type])}
                                        ${Rates.props.destinationCurrencyShort}
                                    </em>
                                    ${Rates.props.dict.plotMin}
                                    <em>
                                        ${Rates.utils.format(this.values.min[type])}
                                        ${Rates.props.destinationCurrencyShort}
                                    </em>
                                </p>
                            </div>
                        `;
                    },

                    getPlotData() {
                        const checkedRange = Rates.utils.getCheckedRange(code);
                        const { ratesDated } = Rates.state.data[code];
                        if (!ratesDated || checkedRange == null) {
                            return null;
                        }

                        const buyValues = [];
                        const sellValues = [];
                        ratesDated.forEach(({ rangeFrom, activeFrom, buyValue, sellValue }) => {
                            if (rangeFrom === checkedRange) {
                                if (![activeFrom, buyValue, sellValue].every($.isNumeric)) {
                                    Rates.utils.log(
                                        'warn',
                                        'bad values for plot with code "%s". %d, %d, %d',
                                        code, activeFrom, buyValue, sellValue
                                    );
                                    return;
                                }

                                this.values.fill('period', activeFrom);
                                this.values.fill('buy', buyValue);
                                this.values.fill('sell', sellValue);

                                buyValues.push([activeFrom, buyValue]);
                                sellValues.push([activeFrom, sellValue]);
                            }
                        });

                        if (!buyValues.length || !sellValues.length) {
                            Rates.utils.log('warn', 'empty values array for code %s', code);
                            return null;
                        }

                        [buyValues, sellValues].forEach(arr => {
                            if (arr.length === 1) {
                                arr[1] = arr[0].slice();
                                // adding some time to be able to build a plot
                                arr[1][0] += 100;
                                this.values.max.period = this.values.min.period + 100;
                            }
                        });
                        return [buyValues.reverse(), sellValues.reverse()];
                    },
                    data: undefined,
                    init() {
                        return $.jqplot('plot-' + code, this.data, {
                            grid: {
                                backgroundColor: 'transparent',
                                borderWidth: 0,
                                shadow: false,
                                shadowColor: 'transparent',
                            },
                            axes: {
                                xaxis: {
                                    borderWidth: 0,
                                    shadow: false,
                                    renderer: $.jqplot.DateAxisRenderer,
                                    rendererOptions: { drawBaseline: true },
                                    tickOptions: { formatString: '%d.%m.%Y' },
                                    min: this.values.min.period,
                                    max: this.values.max.period,
                                    numberTicks: 6,
                                },
                                yaxis: {
                                    borderWidth: 0,
                                    rendererOptions: { drawBaseline: false },
                                    tickOptions: {
                                        formatString: '$%.2f',
                                        tickRenderer: $.jqplot.categoryAxisRenderer,
                                        formatter: (format, value) => (
                                            Rates.utils.format(value) + ' ' + Rates.props.destinationCurrencyShort
                                        ),
                                    },
                                    pad: 0,
                                },
                            },
                            legend: {
                                show: true,
                                placement: 'outsideGrid',
                                location: 's',
                                renderer: $.jqplot.EnhancedLegendRenderer,
                                rendererOptions: { numberRows: 1 },
                            },
                            highlighter: {
                                show: true,
                                showMarker: true,
                                tooltipAxes: 'both',
                                sizeAdjust: 1,
                                lineWidthAdjust: 0.4,
                                tooltipLocation: 'w',
                                tooltipOffset: 15,
                                tooltipContentEditor: (str, seriesIndex, pointIndex) => (
                                    this.getTooltip(['buy', 'sell'][seriesIndex], this.data[seriesIndex][pointIndex])
                                ),
                            },
                            cursor: {
                                style: 'default',
                                showTooltip: false,
                                show: true,
                                showVerticalLine: true,
                                intersectionThreshold: 100,
                                followMouse: true,
                                zoom: true,
                                constrainZoomTo: 'x',
                                clickReset: true,
                            },
                            seriesDefaults: {
                                shadow: false,
                                lineWidth: 2,
                                markerOptions: {
                                    show: false,
                                    style: 'filledCircle',
                                    lineWidth: 3,
                                    size: 11,
                                },
                            },
                            series: [
                                {
                                    label: Rates.props.dict.currentBuy,
                                    color: '#4ec42c',
                                },
                                {
                                    color: '#ffa101',
                                    label: Rates.props.dict.currentSell,
                                },
                            ],
                        });
                    },
                };

                if (Rates.state.data[code].plot) {
                    Rates.state.data[code].plot.destroy();
                }

                plot.data = plot.getPlotData();

                const newStateData = { ...Rates.state.data };

                if (plot.data) {
                    try {
                        newStateData[code].plot = plot.init();
                    } catch (exception) {
                        Rates.utils.log('warn', 'couldn\'t build the plot for code %s', code);
                        newStateData[code].plot = null;
                    }
                } else {
                    Rates.utils.log('warn', 'no data to build the plot for code %s', code);
                    newStateData[code].plot = null;
                }

                $('#plot-' + code).bind('jqplotMouseMove', function(event, gridpos, datapos, neighbor) {
                    if (!neighbor) {
                        return;
                    }

                    const scrolled = $(this).closest('.scroll-content').scrollLeft();
                    const $tooltip = $('.jqplot-highlighter-tooltip');

                    $tooltip.toggleClass('right-sided', event.pageX + scrolled < $tooltip.width() + 100);
                });

                Rates.setState({ data: newStateData });
            });
        },
    };
}
