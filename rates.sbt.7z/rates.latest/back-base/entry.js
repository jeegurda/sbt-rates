import ReactDOM from 'react-dom';

import renderWidget from '../index';

const { tools } = window.SBT.TOOLBOX;

// Имя на которое ориентируется index.html и записи в справочнике DICT_WIDGET_SETTINGS.
// C name в widget.xml может никак не соотносится.
const WIDGET_NAME = 'rates';

// Регистрация init-метода в глобальном неймспейсе.
// Вызов этого метода происходит из index.html.
tools.ns(`SBT.${WIDGET_NAME}`).init = __WIDGET__ => {
    // Не рендерить виджет сразу ({ initialRender: false }),
    // сначала загрузить все (['*']) настройки из справочника DICT_WIDGET_SETTINGS
    // для виджета WIDGET_NAME, для текущего языка и региона.
    tools.initWidget(WIDGET_NAME, __WIDGET__, ['*'], (widgetNode, widgetSettings) => {
        const widgetPreferences = {};
        [
            'exchangeNoteLinkRu',
            'exchangeNoteLinkEn',
            'calculatorLinkRu',
            'calculatorLinkEn',
            'calculatorIncomeLinkRu',
            'calculatorIncomeLinkEn',
            'premierLinkRu',
            'premierLinkEn',
            'firstLinkRu',
            'firstLinkEn',
            'mode',
            'type',
        ].forEach(preferenceName => { widgetPreferences[preferenceName] = __WIDGET__.getPreference(preferenceName); });

        ReactDOM.render(renderWidget(widgetSettings, widgetPreferences), widgetNode);
    }, { initialRender: false });
};
