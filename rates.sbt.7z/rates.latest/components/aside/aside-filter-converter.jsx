import React from 'react';
import autobind from 'autobind-decorator';

import Hint from './../hint/hint';
import Container from './../container/container';
import Button from './../button/button';
import Collapse from 'components/src/collapse/collapse';
import DatePicker from './../date-picker/date-picker';

const cn = require('bem-cn')('rates-aside');
import './aside.css';

const { $ } = window;

export default class AsideFilterConverter extends React.Component {

    constructor(props) {
        super(props);
        this.state = {
            isExpanded: true,
        };
    }

    componentDidMount() {
        this.initSelects();
    }

    initSelects() {
        const { Rates, Aside } = this.props;

        Rates.DOM.converterAmount = this.refs.converterAmount;
        Aside.initSelect(this.refs.converterFrom);
        Aside.initSelect(this.refs.converterTo);
    }

    componentDidUpdate() {
        this.initSelects();
    }

    render() {
        const { Rates, Aside } = this.props;

        let premiumServiceNote;

        // if there is a currency selected which is not in a premiumServiceAllowedCodes array
        // and is not '' (RUR) for first/premium service types, show a warning
        if (Rates.state.converterParams.servicePack !== 'empty') {
            const wrongCodes = [];

            if (
                Rates.state.converterFrom &&
                !Rates.props.premiumServiceAllowedCodes.includes(Rates.state.converterFrom)
            ) {
                wrongCodes.push(Rates.state.data[Rates.state.converterFrom].isoName);
            }
            if (
                Rates.state.converterTo &&
                !Rates.props.premiumServiceAllowedCodes.includes(Rates.state.converterTo)
            ) {
                wrongCodes.push(Rates.state.data[Rates.state.converterTo].isoName);
            }

            if (wrongCodes.length) {
                premiumServiceNote = (
                    <span className={cn('error')}>
                        {Rates.props.dict.converterOptionsError + ': ' + wrongCodes.join(', ')}
                    </span>
                );
            }
        }

        let dataAvailabilityDate;
        // TODO: отрефакторить.
        if (Rates.props.mode === 'converter' && Rates.state.ratesType === 'nal'){
            dataAvailabilityDate = Rates.props.dict[`dataAvailabilityDateConverterNal`];
        } else if (Rates.props.mode === 'currency' || Rates.props.mode === 'converter'){
            dataAvailabilityDate = Rates.props.dict[`dataAvailabilityDateCurrencyConverter${Rates.utils.capitalize(Rates.state.ratesType)}`];
        } else {
            dataAvailabilityDate = Rates.props.dict[`dataAvailabilityDateMetal${Rates.utils.capitalize(Rates.state.ratesType)}`];
        }

        return (
            <Container className={cn('filter')}>
                <Collapse
                    className={cn('collapse')}
                    toggleText={this.state.isExpanded ? Rates.props.dict.hideConverter : Rates.props.dict.showConverter}
                    isExpanded={this.state.isExpanded}
                    onToggleClick={this.handleToggleClick}
                >
                    <div className={cn('filter-block')}>
                        <div>
                            <h6>{Rates.props.dict.filterConverter}</h6>
                        </div>
                        <div className={cn('filter-block-line', { amount: true })}>
                            <div className={cn('filter-block-line-right input')}>
                                <form onSubmit={Aside.updateConverter}>
                                    <input
                                        maxLength="20"
                                        placeholder={Rates.props.dict.filterConverterAmount}
                                        value={Rates.state.converterAmount}
                                        onKeyDown={Aside.onKeyDownAmount}
                                        onChange={Aside.changeAmount}
                                        ref="converterAmount"
                                    />
                                </form>
                            </div>
                        </div>
                        <div className={cn('filter-block-line')}>
                            <div className={cn('filter-block-line-left')}>
                                <span>{Rates.props.dict.filterConverterFrom}</span>
                            </div>
                            <div className={cn('filter-block-line-right')}>
                                <select
                                    ref="converterFrom"
                                    value={Rates.state.converterFrom}
                                    name="converterFrom"
                                    onChange={Aside.selectCode}
                                >
                                    <option key={0} value={''}>{Rates.props.destinationCurrency}</option>
                                    {Rates.utils.getCodes('', true).map((code, c) => (
                                        <option key={c + 1} value={code}>{Rates.state.data[code].isoName}</option>
                                    ))}
                                </select>
                            </div>
                        </div>
                        <div className={cn('filter-block-line')}>
                            <div className={cn('filter-block-line-left')}>
                                <span>{Rates.props.dict.filterConverterTo}</span>
                            </div>
                            <div className={cn('filter-block-line-right')}>
                                <select
                                    ref="converterTo"
                                    value={Rates.state.converterTo}
                                    name="converterTo"
                                    onChange={Aside.selectCode}
                                >
                                    <option key={0} value={''}>{Rates.props.destinationCurrency}</option>
                                    {Rates.utils.getCodes('', true).map((code, c) => (
                                        <option key={c + 1} value={code}>{Rates.state.data[code].isoName}</option>
                                    ))}
                                </select>
                            </div>
                        </div>
                    </div>
                    <div className={cn('filter-block')}>
                        <div>
                            <h6>{Rates.props.dict.filterConverterSource}</h6>
                            <Hint text={Rates.props.dict.filterConverterSourceTip} />
                        </div>
                        {Rates.converter.params[0].values.map(function(el, i) {
                            return (
                                <label key={i} className={el.active ? null : 'filter-inactive'}>
                                    <input
                                        type="radio"
                                        name="sourceCode"
                                        checked={Rates.state.converterParams.sourceCode === el.prop}
                                        value={el.prop}
                                        onChange={Aside.changeConverterParams}
                                    />
                                    <span className="radio" />
                                    <p>
                                        {Rates.props.dict['filterConverterSource' + Rates.utils.capitalize(el.prop)]}
                                    </p>
                                </label>
                            );
                        })}
                    </div>
                    <div className={cn("filter-block")}>
                        <div>
                            <h6>{Rates.props.dict.filterConverterDest}</h6>
                            <Hint text={Rates.props.dict.filterConverterDestTip} />
                        </div>
                        {Rates.converter.params[1].values.map(function(el, i) {
                            return (
                                <label key={i} className={el.active ? null : 'filter-inactive'}>
                                    <input
                                        type="radio"
                                        name="destinationCode"
                                        checked={Rates.state.converterParams.destinationCode === el.prop}
                                        value={el.prop}
                                        onChange={Aside.changeConverterParams}
                                    />
                                    <span className="radio" />
                                    <p>
                                        {Rates.props.dict['filterConverterDest' + Rates.utils.capitalize(el.prop)]}
                                    </p>
                                </label>
                            );
                        })}
                    </div>
                    <div className={cn('filter-block')}>
                        <div>
                            <h6>{Rates.props.dict.filterConverterExchange}</h6>
                            <Hint text={Rates.props.dict.filterConverterExchangeTip} />
                        </div>
                        {Rates.converter.params[2].values.map(function(el, i) {
                            return (
                                <label key={i} className={el.active ? null : 'filter-inactive'}>
                                    <input
                                        type="radio"
                                        name="exchangeType"
                                        checked={Rates.state.converterParams.exchangeType === el.prop}
                                        value={el.prop}
                                        onChange={Aside.changeConverterParams}
                                    />
                                    <span className="radio" />
                                    <p>
                                        {Rates.props.dict['filterConverterExchange' + Rates.utils.capitalize(el.prop)]}
                                    </p>
                                </label>
                            );
                        })}
                    </div>
                    <div className={cn('filter-block')}>
                        <div>
                            <h6>{Rates.props.dict.filterConverterService}</h6>
                            <Hint text={Rates.props.dict.filterConverterServiceTip} />
                        </div>
                        {Rates.converter.params[3].values.map(function(el, i) {
                            return (
                                <label key={i} className={el.active ? null : 'filter-inactive'}>
                                    <input
                                        type="radio"
                                        name="servicePack"
                                        checked={Rates.state.converterParams.servicePack === el.prop}
                                        value={el.prop}
                                        onChange={Aside.changeConverterParams}
                                    />
                                    <span className="radio" />
                                    <p>
                                        {Rates.props.dict['filterConverterService' + Rates.utils.capitalize(el.prop)]}
                                    </p>
                                </label>
                            );
                        })}
                        {premiumServiceNote}
                    </div>
                    <div className={cn('filter-block')}>
                        <div>
                            <h6>{Rates.props.dict.filterConverterDate}</h6>
                            <Hint text={Rates.props.dict.filterConverterDateTip} />
                        </div>
                        {['current', 'select'].map(function(el, i) {
                            return (
                                <label key={i}>
                                    <input
                                        type="radio"
                                        name="converterDateSelect"
                                        checked={Rates.state.converterDateSelect === el}
                                        value={el}
                                        onChange={Aside.changeConverterDate}
                                    />
                                    <span className="radio" />
                                    <p>
                                        {Rates.props.dict['filterConverterDate' + Rates.utils.capitalize(el)]}
                                    </p>
                                </label>
                            );
                        })}
                        {Rates.state.converterDateSelect === 'select' &&
                            <DatePicker
                                inputType="converterDate"
                                isValid={Rates.state.invalidFields.converterDate ? false : true}
                                value={Rates.state.converterDate}
                                minDate={dataAvailabilityDate}
                                timeText={Rates.props.dict.filterConverterDate}
                                closeText={Rates.props.dict.filterConverterDateSelect}
                                onSelect={Rates.handleDatePickerOnSelect}
                            />
                        }
                    </div>
                    <div className={cn('filter-block')}>
                        <Button onClick={Aside.updateConverter}>{Rates.props.dict.show}</Button>
                    </div>
                </Collapse>
            </Container>
        );
    }

    @autobind
    handleToggleClick() {
        this.setState({isExpanded: !this.state.isExpanded});
    }
}
