import React from 'react';
import bem from 'bem-cn';
import autobind from 'autobind-decorator';

import Container from './../container/container';
import Button from './../button/button';
import DatePicker from './../date-picker/date-picker';

import './aside.css';

const cn = bem('rates-aside');

export default class AsideFilterRates extends React.Component {

    componentDidUpdate() {
        const currencySelect = this.refs.currencySelect;
        const { Aside, Rates } = this.props;

        if (currencySelect) {
            Aside.initSelect(currencySelect, function() {
                currencySelect.selectedIndex = -1;
            });
        }
    }

    render() {
        const { Aside, Rates } = this.props;
        let currencySelect;

        // for currency mode and if at least one option isn't selected
        if (
            Rates.state.ratesType !== 'first' &&
            Rates.state.ratesType !== 'premium' &&
            Rates.props.mode === 'currency' &&
            Rates.utils.getCodes('display', true).length
        ) {
            currencySelect = (
                <div className={`${cn('filter-block')} ${cn('filter-block-currency-select')}`}>
                    <div>
                        <h6>{Rates.props.dict.filterSelectCurrency}</h6>
                    </div>
                    <select
                        ref="currencySelect"
                        onChange={Aside.selectCurrency}
                    >
                        {Rates.utils.getCodes('display', true).map(function(code, i) {
                            return (
                                <option key={i} value={code}>{Rates.state.data[code].name}</option>
                            );
                        })}
                    </select>
                </div>
            );
        }

        let availabilityNote;
        let availabilityDate;
        // TODO: отрефакторить.
        if (Rates.props.mode === 'converter' && Rates.state.ratesType === 'nal'){
            availabilityNote = Rates.props.dict[`dataAvailabilityConverterNal`];
            availabilityDate = Rates.props.dict[`dataAvailabilityDateConverterNal`];
        } else if (Rates.props.mode === 'currency' || Rates.props.mode === 'converter'){
            availabilityNote = Rates.props.dict[`dataAvailabilityCurrencyConverter${Rates.utils.capitalize(Rates.state.ratesType)}`];
            availabilityDate = Rates.props.dict[`dataAvailabilityDateCurrencyConverter${Rates.utils.capitalize(Rates.state.ratesType)}`];
        } else {
            availabilityNote = Rates.props.dict[`dataAvailabilityMetal${Rates.utils.capitalize(Rates.state.ratesType)}`];
            availabilityDate = Rates.props.dict[`dataAvailabilityDateMetal${Rates.utils.capitalize(Rates.state.ratesType)}`];
        }

        return (
            <Container className={`${cn('filter')} ${cn('currency')}`}>
                <div className={`${cn('filter-block')} ${cn('filter-block-currency-list')}`}>
                    <div>
                        <h6>{Rates.props.dict['filter' + Rates.utils.capitalize(Rates.props.mode)]}</h6>
                    </div>
                    {Rates.utils.getCodes('display').map(function(code, i) {
                        return (
                            <label key={i}>
                                <input
                                    type="checkbox"
                                    name={code}
                                    checked={Rates.state.data[code].checked}
                                    onChange={Aside.changeCodes}
                                />
                                <span className="checkbox" />
                                <p>{Rates.state.data[code].name}</p>
                            </label>
                        );
                    })}
                </div>
                {currencySelect}
                <div className={cn('filter-block')}>
                    <div>
                        <h6>{Rates.props.dict.filterPeriod}</h6>
                    </div>
                    {['month', 'halfyear', 'quarter', 'year', 'custom'].map((period, p) => (
                        <label className={cn('filter-block-period')} key={p}>
                            <input
                                type="radio"
                                name="period"
                                checked={Rates.state.period === period}
                                value={period}
                                onChange={this.handlePeriodSelect}
                            />
                            <span className="radio" />
                            <p>{Rates.props.dict[`filter${Rates.utils.capitalize(period)}`]}</p>
                        </label>
                    ))}
                </div>
                <div className={`${cn('filter-block')} ${cn('filter-block-period-datepicker')}`}>
                    <div className={cn('filter-block-line')}>
                        <p className={cn('filter-caption')}>{Rates.props.dict.filterFrom}</p>
                        <div className={cn('filter-datepicker')}>
                            <DatePicker
                                inputType='fromDate'
                                isValid={Rates.state.invalidFields.fromDate ? false : true}
                                value={Rates.state.fromDate}
                                maxLength="10"
                                minDate={availabilityDate}
                                timeText={Rates.props.dict.filterConverterDate}
                                closeText={Rates.props.dict.filterConverterDateSelect}
                                toDate={Rates.state.toDate}
                                onSelect={Rates.handleDatePickerOnSelect}
                                onChange={Rates.changeDate}
                                onBlur={Rates.validateInput}
                            />
                        </div>
                    </div>
                    <div className={cn('filter-block-line')}>
                        <p className={cn('filter-caption')}>{Rates.props.dict.filterTo}</p>
                        <div className={cn('filter-datepicker')}>
                            <DatePicker
                                inputType='toDate'
                                isValid={Rates.state.invalidFields.toDate ? false : true}
                                value={Rates.state.toDate}
                                maxLength="10"
                                minDate={availabilityDate}
                                timeText={Rates.props.dict.filterConverterDate}
                                closeText={Rates.props.dict.filterConverterDateSelect}
                                fromDate={Rates.state.fromDate}
                                onSelect={Rates.handleDatePickerOnSelect}
                                onChange={Rates.changeDate}
                                onBlur={Rates.validateInput}
                            />
                        </div>
                    </div>
                </div>
                <div className={cn('filter-block')}>
                    <p className={cn('filter-block-info')}>
                        {availabilityNote}
                        {' '}
                        {availabilityDate}
                    </p>
                    <Button onClick={Aside.updateDetails}>{Rates.props.dict.show}</Button>
                </div>
            </Container>
        );
    }

    @autobind
    handlePeriodSelect(event) {
        this.props.Rates.changePeriod(event.target.value);
    }
}
