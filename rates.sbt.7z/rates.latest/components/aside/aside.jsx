import React from 'react';

import AsideFilterRates from './aside-filter-rates';
import AsideFilterConverter from './aside-filter-converter';
import ConverterResult from './../converter-result/converter-result';

const { $ } = window;

const RatesAside = React.createClass({
    changeCodes(event) {
        const Rates = this.props.Rates;
        const { name, checked } = event.target;

        // if it's not the last checked checkbox
        if (Rates.utils.getCodes('checked').length !== 1 || checked) {
            Rates.setState({
                data: {
                    ...Rates.state.data,
                    [name]: {
                        ...Rates.state.data[name],
                        checked,
                    }
                }
            }, () => {
                Rates.requestCurrent();
                Rates.requestRanges();
            });
        }
    },
    changeConverterDate(event) {
        this.props.Rates.setState({ converterDateSelect: event.target.value });
    },

    changeConverterParams(event) {
        // triggers setState!
        this.props.Rates.setConverterParams({ [event.target.name]: event.target.value });
    },

    updateDetails() {
        this.props.Rates.requestRanges();
        this.props.Rates.requestCurrent();
    },

    updateConverter(event) {
        if (event.type === 'submit') {
            event.preventDefault();
        }
        const Rates = this.props.Rates;

        if (parseInt(
            Rates.state.converterAmount.replace(Rates.utils.regExp.commas, '.').replace(Rates.utils.regExp.spaces, ''),
            10
        ) > 0) {
            this.props.Rates.requestConversion();
        } else {
            Rates.DOM.converterAmount.focus();
        }
    },

    selectCode(event) {
        const value = event.target.value;
        const targetName = event.target.name;
        const otherName = ['converterFrom', 'converterTo'].find(name => name !== targetName);

        const Rates = this.props.Rates;
        const state = { ...Rates.state };

        // Если в одном селекте выставляют значение
        // как в другом - меняем их местами.
        if (state[otherName] === value) {
            state[otherName] = state[targetName];
        }

        state[targetName] = value;

        Object.keys(state.data).forEach(code => {
            state.data[code].checked = (
                // Только иностранные валюты.
                code !== '' &&
                // Выбранные в одном или другом селекте.
                (code === state[targetName] || code === state[otherName])
            );
        });

        Rates.setState(state, () => {
            Rates.actions.requestCurrent();
            // Запросили суммовые градации, которые по завершению загрузки запросят requestDated.
            Rates.actions.requestRanges();
            $([Rates.DOM.converterFrom, Rates.DOM.converterTo]).trigger('update');
            Rates.DOM.converterAmount.focus();
            Rates.DOM.converterAmount.setSelectionRange(100, 100);
        });
    },

    initSelect(el, preCallback) {
        const Rates = this.props.Rates;
        if (!el || el.hasAttribute('data-select-initialized')) {
            return;
        }

        if (preCallback) {
            preCallback();
        }

        Rates.DOM[el.name] = el;
        Rates.plugins.select.call($(el), {
            popup: Rates.plugins.popup,
            allowClickOnActive: 'visual',
            ctx: Rates,
        });
    },

    // counter for currencies which should always appear at the bottom, such as selected ones
    bottomCurrencyOrder: 999,

    selectCurrency(event) {
        const Rates = this.props.Rates;
        const target = event.target;
        const newStateData = { ...Rates.state.data };

        newStateData[target.value].display = true;
        newStateData[target.value].checked = true;
        newStateData[target.value].order = this.bottomCurrencyOrder++;

        Rates.setState({ data: newStateData }, () => {
            target.selectedIndex = -1;
            Rates.actions.requestCurrent(true);
            Rates.actions.requestRanges();
            $(target).trigger('update');
        });
    },

    removingSpace: false,

    onKeyDownAmount(event) {
        const target = event.target;
        // if pressed backspace and it's going to remove the space
        if (event.keyCode === 8 && target.value.charAt(target.selectionStart - 1) === ' ') {
            this.removingSpace = true;
        }
    },

    changeAmount(event) {
        const Rates = this.props.Rates;
        const target = event.target;
        const value = target.value;
        let delimiterFound = false;
        let delimiter;

        // remember cursor position
        const start = target.selectionStart;
        const end = target.selectionEnd;

        // clear the string from non-digits and excessive delimiters
        let clearString = value.replace(Rates.utils.regExp.nonDigits, m => {
            if (!delimiterFound) {
                const match = m.match(Rates.utils.regExp.delimiters);
                if (match) {
                    delimiterFound = true;
                    delimiter = match[0];
                    return match;
                }
            }
            return '';
        });

        // remember how many symbols from user input were cut
        let inputLength = value.length - clearString.length;

        // remove excessive digits
        clearString = clearString.split(delimiter).map((p, i) => p.substr(0, i === 0 ? 12 : 2)).join(delimiter);

        // remember string's length to count spaces after
        const lengthBefore = clearString.length;

        // insert spaces
        clearString = clearString.replace(Rates.utils.regExp.thousands, ' ');

        // substract inserted spaces from cursor position
        inputLength -= (clearString.length - lengthBefore);

        if (this.removingSpace) {
            // remove one position to "jump over" the space (pure usability)
            inputLength++;
            this.removingSpace = false;
        }

        Rates.setState({ converterAmount: clearString }, () => {
            // restore cursor position
            target.setSelectionRange(start - inputLength, end - inputLength);
        });
    },

    componentDidUpdate() {
        const Rates = this.props.Rates;
    },

    render() {
        const Rates = this.props.Rates;

        return (
            <aside className="rates-aside print-invisible">
                {Rates.props.mode === 'converter' ? (
                    <div>
                        <AsideFilterConverter Rates={Rates} Aside={this} key="0" />
                        <ConverterResult ref="Result" Rates={Rates} Aside={this} key="1" />
                    </div>
                ) : (
                    <AsideFilterRates Rates={Rates} Aside={this} />
                )}
            </aside>
        );
    },
});

export default RatesAside;
