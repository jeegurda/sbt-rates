import React from 'react';
import bem from 'bem-cn';

import './button.css';

const cn = bem('rates-button');

export default props => (
    <button
        className={cn.mix(props.className)}
        onClick={props.onClick}
    >
        {props.children}
    </button>
);
