import React from 'react';
import bem from 'bem-cn';
import autobind from 'autobind-decorator';

import './container.css';

const { $ } = window;
const cn = bem('rates-container');

export default class Container extends React.Component {
    static propTypes = {
        className: React.PropTypes.any,
        onClickOutside: React.PropTypes.func,
    };

    componentDidMount() {
        $(document).on('click', this.handleDocumentClick);
    }

    componentWillUnmount() {
        $(document).off('click', this.handleDocumentClick);
    }

    render() {
        const { className, children } = this.props;
        return (
            <div className={cn.mix(className)} ref="container">
                {children}
            </div>
        );
    }

    @autobind
    handleDocumentClick(event) {
        if (!this.props.onClickOutside) {
            return;
        }

        const { clientX, clientY } = event;
        const { top, left, bottom, right } = this.refs.container.getBoundingClientRect();

        if (clientX < left || clientX > right || clientY < top || clientY > bottom) {
            this.props.onClickOutside(event);
        }
    }
}
