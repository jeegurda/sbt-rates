import React from 'react';
import bem from 'bem-cn';

import './converter-result.css';

const { $ } = window;
const cn = bem('rates-converter-result');

const ConverterResult = React.createClass({
    resultVisible: false,
    resultTransformedOffset: 50, // initial transformed offset
    resultOffset: 25, // additional offset for readability

    scrollToResult() {
        if (this.refs.converterResult && this.props.Rates.state.converterResult.valid) {
            const result = this.refs.converterResult;
            const resultBottom =
                result.getBoundingClientRect().bottom +
                this.resultOffset +
                (this.resultVisible ? 0 : this.resultTransformedOffset);
            const diff = resultBottom - window.innerHeight;

            this.resultVisible = true;

            if (diff > 0) {
                $('html, body').animate({ scrollTop: $(window).scrollTop() + diff }, 200);
            }
        } else {
            this.resultVisible = false;
        }
    },

    render() {
        const { Rates } = this.props;
        const { dict, destinationCurrency } = Rates.props;
        const { converterResult, data } = Rates.state;
        const { value, valid, from, to, amount, crossRate } = converterResult;

        if (!$.isNumeric(value) || !valid) {
            return null;
        }

        return (
            <div className={cn} ref="converterResult">
                <div className={cn('total')}>
                    <span className={cn('total-title')}>
                        {dict.filterConverterResult}
                        {' '}
                    </span>
                    <span className={cn('total-from')}>
                        {Rates.utils.format(amount)}
                        {' '}
                        {from ? data[from].isoName : destinationCurrency}
                        {' = '}
                    </span>
                    <span className={cn('total-to')}>
                        {Rates.utils.format(value)}
                        {' '}
                        {to ? data[to].isoName : destinationCurrency}
                    </span>
                </div>
                {/* Только для кросс-курса (ни одна ваюта не рубль). */}
                {!!from && !!to && (
                    <div className={cn('rate')}>
                        <span className={cn('rate-from')}>
                            {'1 '}
                            {data[from].isoName}
                            {' = '}
                        </span>
                        <span className={cn('rate-to')}>
                            {Rates.utils.format(crossRate)}
                            {' '}
                            {data[to].isoName}
                        </span>
                    </div>
                )}
            </div>
        );
    },
});

export default ConverterResult;
