import React from 'react';
import bem from 'bem-cn';

import Container from './../container/container';
import './current.css';

const { moment } = window;
const cn = bem('rates-current');

const Current = React.createClass({
    render() {
        const { Rates } = this.props;
        const { ratesType } = Rates.state;
        const { mode, dict, language } = Rates.props;

        const modeSuffix = Rates.utils.capitalize(mode);
        const typeSuffix = Rates.utils.capitalize(ratesType);
        const langSuffix = Rates.utils.capitalize(language);

        const notes = [];

        if (['first', 'premium'].includes(ratesType)) {
            const noteText = dict[`currentNoteFragment${mode === 'metal' ? 'Metal' : 'Currency'}`];
            const noteLinkUrl = dict[`${ratesType}Link${langSuffix}`];
            const noteLinkText = dict.currentNoteFragmentLink.format(dict[`currentNote${typeSuffix}`]);
            const noteLink = `<a href="${noteLinkUrl}" target="_blank">${noteLinkText}</a>`;
            notes.push(`<strong>${dict.currentNoteBold}</strong> ${noteText.format(noteLink)}`);
        }

        const { converterParams, converterFrom, converterTo } = Rates.state;
        const { sourceCode, destinationCode } = converterParams;
        const { limitedExchangeCodes } = Rates.props;
        if (
            [sourceCode, destinationCode].every(code => code === 'cash') &&
            limitedExchangeCodes.some(code => code === converterFrom || code === converterTo)
        ) {
            const exchangeNoteLinkUrl = dict[`exchangeNoteLink${langSuffix}`];
            const exchangeNoteLinkText = dict.exchangeNoteLinkText;
            const exchangeNoteLink = `<a href="${exchangeNoteLinkUrl}" target="_blank">${exchangeNoteLinkText}</a>`;
            notes.push(dict.exchangeNote.format(exchangeNoteLink));
        }

        notes.push(dict[`detailsNote${modeSuffix}`]);

        let links;
        if (mode === 'metal') {
            links = (
                <a className={cn('link')} href={dict[`calculatorIncomeLink${langSuffix}`]}>
                    {dict.calculatorIncome}
                </a>
            );
        } else if (mode === 'currency') {
            links = (
                <a className={cn('link')} href={dict[`calculatorLink${langSuffix}`]}>
                    {dict.calculator}
                </a>
            );
        }

        // Для конвертера нужно гарантировать порядок валют в списке.
        const codes = mode === 'converter'
            ? [converterFrom, converterTo]
            : Rates.utils.getCodes('checked');
        const rates = codes
            .map(code => Rates.state.data[code])
            .filter(rate => rate && rate.ratesCurrent);
        if (!rates.length) {
            return null;
        }

        // Отображается масштаб валюты, если он отличен от 1.
        const showScaleColumn = rates.some(rate => rate.ratesCurrent.scale > 1);

        return (
            <div className={cn.mix('rates-right')}>
                <Container className={cn('container')}>
                    <div className={cn('table-wrapper')}>
                        <table className={cn('table')}>
                            <tbody>
                                <tr className={cn('table-row', { header: true })}>
                                    <td className={cn('table-cell', { column: 'name' })}>
                                        {dict[`current${mode === 'metal' ? 'Metal' : 'Currency'}`]}
                                    </td>
                                    {showScaleColumn && (
                                        <td className={cn('table-cell', { column: 'scale' })}>{dict.currentAmount}</td>
                                    )}
                                    <td className={cn('table-cell', { column: 'buy' })}>{dict.currentBuy}</td>
                                    <td className={cn('table-cell', { column: 'sell' })}>{dict.currentSell}</td>
                                </tr>
                                {rates.map(({ ratesCurrent, name, isoName }, r) => {
                                    const { buyChange, sellChange, buyValue, sellValue, scale } = ratesCurrent;

                                    const buyTitle = (
                                        buyChange > 0
                                        ? `${dict.currentIncrease}: ${Rates.utils.format(buyChange)}`
                                        : (
                                            buyChange < 0
                                            ? `${dict.currentDecrease}: ${Rates.utils.format(buyChange)}`
                                            : null
                                        )
                                    );

                                    const sellTitle = (
                                        sellChange > 0
                                        ? `${dict.currentIncrease}: ${Rates.utils.format(sellChange)}`
                                        : (
                                            sellChange < 0
                                            ? `${dict.currentDecrease}: ${Rates.utils.format(sellChange)}`
                                            : null
                                        )
                                    );

                                    return (
                                        <tr className={cn('table-row', { odd: rates.length > 1 && r % 2 === 0 })} key={r}>
                                            {mode === 'metal'
                                                ? (
                                                    <td className={cn('table-cell', { column: 'name' })}>
                                                        {name}
                                                    </td>
                                                ) : (
                                                    <td className={cn('table-cell', { column: 'name' })}>
                                                        {isoName}
                                                        {' '}
                                                        <span className={cn('dest-currency')}>
                                                            / {Rates.props.destinationCurrency}
                                                        </span>
                                                    </td>
                                                )
                                            }
                                            {showScaleColumn && (
                                                <td className={cn('table-cell', { column: 'scale' })}>
                                                    {scale}
                                                </td>
                                            )}
                                            <td className={cn('table-cell', { column: 'buy' })}>
                                                {typeof buyValue !== 'number' ? '\u2014' : (
                                                    <span
                                                        title={buyTitle}
                                                        className={cn('rate', {
                                                            increase: buyChange > 0,
                                                            decrease: buyChange < 0,
                                                        })}
                                                    >
                                                        <span className={cn('rate-value')}>
                                                            {Rates.utils.format(buyValue)}
                                                        </span>
                                                        <span className={cn('rate-indicator')} />
                                                        <span className={cn('rate-change')}>
                                                            {Rates.utils.format(buyChange)}
                                                        </span>
                                                    </span>
                                                )}
                                            </td>
                                            <td className={cn('table-cell', { column: 'sell' })}>
                                                {typeof sellValue !== 'number' ? '\u2014' : (
                                                    <span
                                                        title={sellTitle}
                                                        className={cn('rate', {
                                                            increase: sellChange > 0,
                                                            decrease: sellChange < 0,
                                                        })}
                                                    >
                                                        <span className={cn('rate-value')}>
                                                            {Rates.utils.format(sellValue)}
                                                        </span>
                                                        <span className={cn('rate-indicator')} />
                                                        <span className={cn('rate-change')}>
                                                            {Rates.utils.format(sellChange)}
                                                        </span>
                                                    </span>
                                                )}
                                            </td>
                                        </tr>
                                    );
                                })}
                            </tbody>
                        </table>
                    </div>
                    <div className={cn('info')}>
                        {dict.currentInfo.format(
                            dict[`currentInfo${modeSuffix}`],
                            moment(Rates.state.ratesCurrentLatestChange).format(Rates.props.dateFormat + ' H:mm')
                        )}
                    </div>
                    {notes.filter(html => html && html.trim()).map((html, h) => (
                        <div
                            key={h}
                            className={cn('note')}
                            dangerouslySetInnerHTML={{ __html: html }}
                        />
                    ))}
                </Container>
                {links}
            </div>
        );
    },
});

export default Current;
