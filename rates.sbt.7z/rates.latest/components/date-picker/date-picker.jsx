import React from 'react';
import autobind from 'autobind-decorator';

import './date-picker.css';

const cn = require('bem-cn')('rates-date-picker');

const { moment, $ } = window;

export default class DatePicker extends React.Component {
    static propTypes = {
        value: React.PropTypes.string,
        inputType: React.PropTypes.string,
        dateFormat: React.PropTypes.string,
        timeFormat: React.PropTypes.string,
        ratesType: React.PropTypes.string,
        minDate: React.PropTypes.string,
        timeText: React.PropTypes.string,
        closeText: React.PropTypes.string,
        fromDate: React.PropTypes.string,
        isValid: React.PropTypes.bool,
        toDate: React.PropTypes.string,
        onChange: React.PropTypes.func,
        onSelect: React.PropTypes.func,
        onBlur: React.PropTypes.func,
    }

    static defaultProps = {
        inputType: '',
        timeText: 'Время',
        closeText: 'Выбрать',
        dateFormat: 'DD.MM.YYYY',
        timeFormat: 'HH:mm',
        isValid: true,
        onChange: () => {},
        onSelect: () => {},
        onBlur: () => {},
    };

    componentDidMount() {
        this.initDatepicker(this.refs.input);
        $(document.body).on('click', '.rates-button_converter-datepicker-hide', () => {
            $(this.refs.input).datepicker('hide');
        });
    }

    initDatepicker(el) {
        if (!el) {
            return;
        }

        const $el = $(el);

        const { inputType, minDate, dateFormat } = this.props;
        const minMoment = moment(minDate, dateFormat);
        const maxMoment = moment();

        const datepickerOptions = {
            changeYear: true,
            yearRange: `${minMoment.get('year')}:${maxMoment.get('year')}`,
            minDate: minMoment.toDate(),
            maxDate: maxMoment.toDate(),
            onSelect: value => {
                this.props.onSelect(inputType, value);
            },
        };

        if (inputType === 'converterDate') {
            const { timeFormat, timeText, closeText } = this.props;
            $el.datetimepicker({
                ...datepickerOptions,
                timeFormat,
                timeText,
                closeText,
                controlType: 'select',
                oneLine: true,
                showButtonPanel: false,
                stepMinute: 5,
            });
        } else {
            $el.datepicker({
                ...datepickerOptions,
                beforeShow: () => {
                    const { fromDate, toDate } = this.props;
                    if (inputType === 'fromDate') {
                        $el.datetimepicker('option', 'maxDate', moment(toDate, dateFormat).toDate());
                    } else if (inputType === 'toDate') {
                        $el.datetimepicker('option', 'minDate', moment(fromDate, dateFormat).toDate());
                    }
                },
            });
        }
    }

    componentWillReceiveProps() {
        this.initDatepicker(this.refs.input);
    }

    shouldComponentUpdate() {
        return false;
    }

    render() {
        return (
            <div className={cn('wrapper')} ref="wrapper">
                <input
                    ref="input"
                    className={cn('input', {invalid: !this.props.isValid})}
                    value={this.props.value}
                    data-property={this.props.inputType}
                    onChange={this.props.onChange}
                    onBlur={this.props.onBlur}
                />
                <button
                    className={cn('trigger')}
                    ref="trigger"
                    onClick={this.handleOnTriggerClick}
                />
            </div>
        );
    }

    @autobind
    handleOnTriggerClick() {
        this.refs.input.focus();
    }
}
