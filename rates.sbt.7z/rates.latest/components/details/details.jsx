import React from 'react';
import bem from 'bem-cn';

import Button from '../button/button';
import Container from '../container/container';
import DatePicker from '../date-picker/date-picker';

import './details.css';
import logoFileName from './logo.svg';

const { $ } = window;
const cn = bem('rates-details');

const assetsRootPath = process.env.NODE_ENV !== 'development' ? '/portalserver/static/sb-bundle/widgets/assets/' : '';
const Details = React.createClass({
    render() {
        const { Rates } = this.props;
        const { mode } = Rates.props;
        const { converterFrom, converterTo, printSection, data } = Rates.state;

        const codes = (
            // В конвертере важен порядок графиков.
            mode === 'converter'
            ? [converterFrom, converterTo]
            : Rates.utils.getCodes('checked')
        ).filter(code => (data[code] || {}).ratesDated);

        return (
            <div className="rates-right">
                <div className={cn}>
                    {mode === 'converter' && this.renderFilter()}
                    <div className="rates-details-graphs">
                        {codes.map(code => {
                            const item = data[code];
                            // important to use 'code' here as a key, so that div with a graph could be properly removed
                            return (
                                <div
                                    className={'details-item ' + (printSection === code ? 'print-visible' : 'print-invisible')}
                                    key={code}
                                >
                                    <Button className={cn('print-preview-button')} onClick={Rates.printClose}>Закрыть</Button>
                                    <Button className={cn('print-preview-button')} onClick={Rates.printStart}>Печать</Button>
                                    <img
                                        className={cn('print-logo')}
                                        src={`${assetsRootPath}${logoFileName}`}
                                        role="presentation"
                                        alt="Sberbank"
                                    />
                                    <h2 className={cn('graph-title')}>{item.name}</h2>
                                    <div>{this.renderDetails(item, code)}</div>
                                </div>
                            );
                        })}
                    </div>
                    {this.renderNotes()}
                </div>
            </div>
        );
    },

    renderFilter() {
        const { Rates } = this.props;
        const { dict } = Rates.props;
        const { ratesType, invalidFields, fromDate, toDate } = Rates.state;

        let dataAvailabilityDate;
        if (ratesType === 'nal') {
            dataAvailabilityDate = dict[`dataAvailabilityDateConverterNal`];
        } else {
            dataAvailabilityDate = dict[`dataAvailabilityDateCurrencyConverter${Rates.utils.capitalize(ratesType)}`];
        }

        return (
            <div className={cn('filter').mix('print-invisible')}>
                <div className={cn('filter-inputs')}>
                    <span className={cn('filter-label')}>
                        {dict.filterFrom}
                    </span>
                    <div className={cn('filter-input')}>
                        <DatePicker
                            inputType='fromDate'
                            value={fromDate}
                            maxLength="10"
                            isValid={(invalidFields.fromDate) ? false : true}
                            minDate={dataAvailabilityDate}
                            timeText={Rates.props.dict.filterConverterDate}
                            closeText={Rates.props.dict.filterConverterDateSelect}
                            toDate={Rates.state.toDate}
                            onSelect={Rates.handleDatePickerOnSelect}
                            onChange={this.changeDate}
                            onBlur={Rates.validateInput}
                        />
                    </div>
                    <span className={cn('filter-label')}>
                        {dict.filterTo}
                    </span>
                    <div className={cn('filter-input')}>
                        <DatePicker
                            inputType='toDate'
                            value={toDate}
                            maxLength="10"
                            isValid={(invalidFields.toDate) ? false : true}
                            minDate={dataAvailabilityDate}
                            timeText={Rates.props.dict.filterConverterDate}
                            closeText={Rates.props.dict.filterConverterDateSelect}
                            fromDate={Rates.state.fromDate}
                            onSelect={Rates.handleDatePickerOnSelect}
                            onChange={this.changeDate}
                            onBlur={Rates.validateInput}
                        />
                    </div>
                </div>
                <Button className={cn('filter-button')} onClick={this.updateDetails}>
                    {dict.show}
                </Button>
            </div>
        );
    },

    renderDetails(item, code) {
        const { Rates } = this.props;
        const { dict } = Rates.props;

        // if data for code is missing (no ranges) or plot wasn't built (no data, empty values array, jqplot errors)
        if (item.ratesDated === 'NODATA' || item.plot === null) {
            return (
                <div>
                    <div>{dict.noData}</div>
                    <div id={`plot-${code}`} className={cn('plot', { 'no-data': true })} />
                </div>
            );
        }

        return (
            <div>
                <div className={cn('links').mix('print-invisible')}>
                    <span className={cn('link', { action: 'print' })}>
                        <span className={cn('link-text')} onClick={Rates.print.bind(null, code)}>
                            {dict.print}
                        </span>
                    </span>
                    <span className={cn('link', { action: 'show-table' })}>
                        <span className={cn('link-text')} onClick={Rates.showTableView.bind(null, code)}>
                            {dict.tableView}
                        </span>
                    </span>
                    {item.ranges.length > 1 && (
                        <span className={cn('link', { action: 'show-ranges' })}>
                            <span
                                className={cn('link-text')}
                                data-code={code}
                                onClick={this.handleShowRangesClick}
                            >
                                {dict.detailsSelectRange}
                            </span>
                            {item.rangesVisible &&
                                <Container className={cn('ranges')} onClickOutside={this.handleClickOutsideRanges}>
                                    <div className={cn('link', { action: 'hide-ranges' })}>
                                        <span className={cn('link-text')}>
                                            {dict.detailsSelectRange}
                                        </span>
                                    </div>
                                    {this.getRangesDescription(item.ranges).map((description, d) => (
                                        <span
                                            key={d}
                                            className={cn('link', {
                                                action: 'select-range',
                                                checked: item.ranges[d].checked
                                            })}
                                        >
                                            <span
                                                className={cn('link-text')}
                                                data-code={code}
                                                data-amount-from={item.ranges[d].amountFrom}
                                                onClick={this.handleSelectRangeLinkClick}
                                            >
                                                {description}
                                            </span>
                                        </span>
                                    ))}
                                </Container>
                            }
                        </span>
                    )}
                </div>
                <div className={cn('scroll')}>
                    <div className={cn('print-preview-overlay')} />
                    <div id={`plot-${code}`} className={cn('plot')} />
                </div>
            </div>
        );
    },

    getRangesDescription(ranges) {
        return Object.keys(ranges)
            .map(el => ranges[el].amountFrom)
            .sort((a, b) => a - b)
            .map((el, i, arr) => {
                let nextMax = el;
                for (let j = i; j < arr.length; j++) {
                    if (arr[j] > el) {
                        nextMax = arr[j];
                        break;
                    }
                }
                return (
                    nextMax === el
                        ? this.props.Rates.props.dict.detailsRangeFrom + ' ' + el
                        : el + '-' + nextMax
                );
            });
    },

    renderNotes() {
        const { Rates } = this.props;
        const { dict, mode } = Rates.props;
        const { ratesType } = Rates.state;
        let availabilityNote;
        let availabilityDate;
        if (mode === 'converter' && ratesType === 'nal'){
            availabilityNote = dict[`dataAvailabilityConverterNal`];
            availabilityDate = dict[`dataAvailabilityDateConverterNal`];
        } else if (mode === 'currency' || mode === 'converter'){
            availabilityNote = dict[`dataAvailabilityCurrencyConverter${Rates.utils.capitalize(ratesType)}`];
            availabilityDate = dict[`dataAvailabilityDateCurrencyConverter${Rates.utils.capitalize(ratesType)}`];
        } else {
            availabilityNote = dict[`dataAvailabilityMetal${Rates.utils.capitalize(ratesType)}`];
            availabilityDate = dict[`dataAvailabilityDateMetal${Rates.utils.capitalize(ratesType)}`];
        }
        return (
            <div className={cn('notes').mix('print-invisible')}>
                {availabilityNote}
                {' '}
                {availabilityDate}
            </div>
        );
    },

    updateDetails() {
        this.props.Rates.requestRanges();
        this.props.Rates.requestCurrent();
    },

    changeDate(event) {
        this.props.Rates.changeDate(event);
    },

    handleClickOutsideRanges() {
        this.toggleRanges();
    },

    toggleRanges(clickedCode) {
        const { Rates } = this.props;
        const newStateData = { ...Rates.state.data };
        Object.keys(newStateData).forEach(code => {
            newStateData[code].rangesVisible = code === clickedCode;
        });
        Rates.setState({ data: newStateData });
    },

    handleShowRangesClick(event) {
        const code = event.currentTarget.getAttribute('data-code');
        this.toggleRanges(code);
    },

    handleSelectRangeLinkClick(event) {
        const { Rates } = this.props;

        const target = event.currentTarget;
        const code = target.getAttribute('data-code');
        const amountFrom = parseInt(target.getAttribute('data-amount-from'), 10);

        const newStateData = { ...Rates.state.data };
        newStateData[code].ranges.forEach(range => {
            range.checked = range.amountFrom === amountFrom;
        });

        Rates.setState({ data: newStateData }, () => {
            this.toggleRanges();
            Rates.drawPlot(code);
        });
    },
});

export default Details;
