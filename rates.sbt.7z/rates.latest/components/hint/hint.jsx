import React from 'react';
import ReactDOM from 'react-dom';
import bem from 'bem-cn';

import './hint.css';

const cn = bem('rates-hint');

const TOOLTIP_VERTICAL_OFFSET_PX = 8;
const TOOLTIP_HORIZONTAL_OFFSET_PX = 10;
const ACTIVE_EXTENSION_PX = 10;

const Hint = React.createClass({
    getDefaultProps() {
        return {
            text: null,
        };
    },

    componentWillMount() {
        this.tooltip = document.createElement('div');
        this.tooltip.className = cn('tooltip').mix('sbr-tooltip-tooltip');
        document.body.appendChild(this.tooltip);
        this.renderText();
    },

    renderText() {
        ReactDOM.render(<div>{this.props.text}</div>, this.tooltip);
    },

    componentDidUpdate() {
        this.renderText();
    },

    componentWillUnmount() {
        ReactDOM.unmountComponentAtNode(this.tooltip);
        document.body.removeChild(this.tooltip);
    },

    getIconClassName(active, direction) {
        return (
            cn('icon', {
                active,
                direction,
            }).toString()
        );
    },

    isMouseOverRect(event, rect) {
        return (
            event.clientX >= rect.left &&
            event.clientX <= rect.right &&
            event.clientY >= rect.top &&
            event.clientY <= rect.bottom
        );
    },

    render() {
        return (
            <span
                className={this.getIconClassName()}
                ref="icon"
                onMouseOver={this.handleMouseOverIcon}
            >
                ?
            </span>
        );
    },

    handleMouseOverIcon() {
        const tooltip = this.tooltip;
        const icon = this.refs.icon;
        // Отображаем тултип невидимым, чтобы получить размеры.
        let tooltipStyle = {
            top: '-1000px',
            right: null,
            left: null,
            visibility: 'hidden',
            display: 'block',
        };
        Object.keys(tooltipStyle).forEach(prop => {
            tooltip.style[prop] = tooltipStyle[prop];
        });

        const tooltipRect = tooltip.getBoundingClientRect();
        const iconRect = icon.getBoundingClientRect();
        const tooltipHeight = tooltipRect.bottom - tooltipRect.top;
        const tooltipWidth = tooltipRect.right - tooltipRect.left;
        const iconHeight = iconRect.bottom - iconRect.top;
        const bodyRect = document.body.getBoundingClientRect();
        // В какую сторону раскрыть тултип, вниз или вверх
        const direction = iconRect.top - tooltipHeight >= 0 ? 'up' : 'down';
        const windowWidth = window.innerWidth;
        // К какому краю приклеить тултип, если он слишком большой
        let overflows = 'none';
        if (tooltipWidth >= windowWidth) {
            overflows = 'both';
        } else if (iconRect.left - bodyRect.left + tooltipWidth >= windowWidth) {
            overflows = 'right';
        }
        tooltipStyle = {
            top: `${Math.round(
                // Смещение верхнего края иконки относительно страницы
                iconRect.top - bodyRect.top + (
                    direction === 'up'
                        ? -(tooltipHeight + TOOLTIP_VERTICAL_OFFSET_PX)
                        : iconHeight + TOOLTIP_VERTICAL_OFFSET_PX
                )
            )}px`,
            left: (
                overflows === 'both' ? 0 :
                overflows === 'right' ? null :
                `${Math.round(iconRect.left - bodyRect.left - TOOLTIP_HORIZONTAL_OFFSET_PX)}px`
            ),
            right: overflows === 'right' ? 0 : null,
            visibility: 'visible',
        };
        Object.keys(tooltipStyle).forEach(prop => {
            tooltip.style[prop] = tooltipStyle[prop];
        });

        icon.className = this.getIconClassName(true, direction);

        const self = this;
        // Иначе сработает сразу и закроет тултип.
        setTimeout(() => {
            document.addEventListener('mousemove', self.handleMouseMove);
        }, 0);
    },

    handleMouseMove(event) {
        const tooltip = this.tooltip;
        const icon = this.refs.icon;
        const iconRect = icon.getBoundingClientRect();
        const tooltipRect = tooltip.getBoundingClientRect();
        const iconRectExtended = {
            left: iconRect.left - ACTIVE_EXTENSION_PX,
            right: iconRect.right + ACTIVE_EXTENSION_PX,
            top: Math.min(tooltipRect.top, iconRect.top - ACTIVE_EXTENSION_PX),
            bottom: Math.max(tooltipRect.bottom, iconRect.bottom + ACTIVE_EXTENSION_PX),
        };
        const tooltipRectExtended = {
            left: tooltipRect.left - ACTIVE_EXTENSION_PX,
            right: tooltipRect.right + ACTIVE_EXTENSION_PX,
            top: tooltipRect.top - ACTIVE_EXTENSION_PX,
            bottom: tooltipRect.bottom + ACTIVE_EXTENSION_PX,
        };
        const isMouseOut = (
            !this.isMouseOverRect(event, iconRectExtended) && !this.isMouseOverRect(event, tooltipRectExtended)
        );
        if (isMouseOut) {
            this.tooltip.style.display = 'none';
            icon.className = this.getIconClassName();
            document.removeEventListener('mousemove', this.handleMouseMove);
        }
    },
});

export default Hint;
