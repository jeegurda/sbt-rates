import React from 'react';

import '../../libs/jquery.jqplot.min';
import '../../libs/jqplot.cursor.min';
import '../../libs/jqplot.dateAxisRenderer.min';
import '../../libs/jqplot.enhancedLegendRenderer.min';
import '../../libs/jqplot.highlighter.min';
import '../../libs/jquery-ui-timepicker-addon';

import initActions from '../../api';
import combinations from './combinations';
import sbrPluginSelect from '../../libs/SBR.plugin.select';
import sbrPluginPopup from '../../libs/SBR.plugin.popup';
import Aside from '../aside/aside';
import Current from '../current/current';
import Details from '../details/details';
import TableView from '../table-view/table-view';

import './rates.css';

const { moment, $ } = window;

const Rates = React.createClass({
    DOM: {},
    closestValidValue: null,

    componentWillMount() {
        this.utils = this.initUtils();
    },

    componentDidMount() {
        if (this.state.period === 'custom') {
            this.setState({
                fromDate: moment().subtract(1, 'week').format(this.props.dateFormat),
                toDate: moment().format(this.props.dateFormat),
            });
        }
        this.changePeriod(this.state.period);

        this.actions = initActions(this);

        this.initConverter();

        this.actions.requestInfo();
        this.requestCurrent();
        this.requestRanges();
    },

    getInitialState() {
        const props = this.props;

        return {
            error: { info: false },
            cachedParams: {
                converter: {},
                dated: {},
                datedBody: {},
                detailed: {},
                ranges: {},
            },
            invalidFields: {},
            ratesCurrentLatestChange: 0,
            converterAmount: props.converterAmount,
            get converterDate() {
                const today = (new Date());
                const hours = today.getHours();
                const minutes = Math.floor(today.getMinutes() / 5) * 5;

                return moment().format(props.dateFormat)
                    + ' ' + (hours < 10 ? '0' + hours : hours)
                    + ':' + (minutes < 10 ? '0' + minutes : minutes);
            },
            converterDateSelect: 'current',
            converterFrom: props.sourceCurrencyCode,
            converterResult: {
                amount: '',
                value: null,
                from: '',
                to: '',
                valid: false,
            },
            converterTo: props.destCurrencyCode,
            converterParams: {},
            data: $.extend(true, {}, props.codes),
            fromDate: null,
            period: props.period,
            toDate: null,
            ratesType: props.ratesType,
        };
    },

    render() {
        let widgetContent;

        if (this.state.error.info) {
            widgetContent = (
                <div>{this.props.dict.loadingError}</div>
            );
        } else if (this.utils.getCodes('name').length) {
            widgetContent = [
                <Current Rates={this} ref="Current" key="0" />,
                <Aside Rates={this} ref="Aside" key="1" />,
                <Details Rates={this} ref="Details" key="3" />,
                this.state.tableView && <TableView Rates={this} ref="Modal" key="4" />,
            ];
        } else {
            widgetContent = <div>{this.props.dict.loading}</div>;
        }

        return (
            <div className="widget-rates">
                {widgetContent}
            </div>
        );
    },

    hideTableView() {
        this.setState({ tableView: null });
    },

    showTableView(code) {
        this.setState({ tableView: code });
    },

    changePeriod(newPeriod) {
        let fromDate;
        const dateFormat = this.props.dateFormat;
        const today = moment();

        if (newPeriod !== 'custom') {
            if (newPeriod === 'month') {
                fromDate = moment().subtract(1, 'month').format(dateFormat);
            } else if (newPeriod === 'halfyear') {
                fromDate = moment().subtract(6, 'month').format(dateFormat);
            } else if (newPeriod === 'quarter') {
                fromDate = moment().subtract(1, 'quarter').format(dateFormat);
            } else if (newPeriod === 'year') {
                fromDate = moment().subtract(1, 'year').format(dateFormat);
            } else {
                this.utils.log('error', 'Rates: unknown period literal');
            }

            this.setState({
                fromDate,
                toDate: today.format(dateFormat),
            });
        }

        this.setState({ period: newPeriod });
    },

    validateInput(event) {
        const inputType = event.target.getAttribute('data-property');

        if (this.state.invalidFields[inputType]) {
            this.setState({
                [inputType]: this.closestValidValue,
                invalidFields: {
                    ...this.state.invalidFields,
                    [inputType]: false,
                },
            });
        }

        this.closestValidValue = null;
    },

    changeDate(event) {
        const { dict, dateFormat, mode } = this.props;

        const inputType = event.target.getAttribute('data-property');
        const inputValue = event.target.value;
        const inputMoment = moment(inputValue, dateFormat);

        const { ratesType, toDate, fromDate } = this.state;

        let dataAvailabilityDate;
        if (mode === 'converter' && ratesType === 'nal'){
            dataAvailabilityDate = dict[`dataAvailabilityDateConverterNal`];
        } else if (mode === 'currency' || mode === 'converter'){
            dataAvailabilityDate = dict[`dataAvailabilityDateCurrencyConverter${this.utils.capitalize(ratesType)}`];
        } else {
            dataAvailabilityDate = dict[`dataAvailabilityDateMetal${this.utils.capitalize(ratesType)}`];
        }
        const dataAvailabilityMoment = moment(dataAvailabilityDate, dateFormat);
        const fromMoment = moment(fromDate, dateFormat);
        const toMoment = moment(toDate, dateFormat);
        const nowMoment = moment();

        let isValid = true;
        let closestValidValue = null;

        if (!inputMoment.isValid()) {
            isValid = false;
            closestValidValue = this.state[inputType];
        } else {
            const [minMoment, maxMoment] =
                inputType === 'fromDate'
                ? [dataAvailabilityMoment, toMoment]
                : [fromMoment, nowMoment];

            if (inputMoment < minMoment) {
                isValid = false;
                closestValidValue = minMoment.format(dateFormat);
            }

            if (inputMoment > maxMoment) {
                isValid = false;
                closestValidValue = maxMoment.format(dateFormat);
            }
        }
        this.closestValidValue = closestValidValue;

        this.setState({
            [inputType]: inputValue,
            invalidFields: {
                ...this.state.invalidFields,
                [inputType]: !isValid,
            },
        });
    },

    onDatedLoaded() {
        this.drawPlot();
    },

    onRangesLoaded() {
        this.requestDated();
    },

    handleDatePickerOnSelect(inputType, value) {
        this.setState({
            period: 'custom',
            [inputType]: value,
        });
    },

    converter: {
        combinations,
        params: [
            {
                name: 'sourceCode',
                values: [
                    { prop: 'card', active: true },
                    { prop: 'account', active: true },
                    { prop: 'cash', active: true },
                ],
            },
            {
                name: 'destinationCode',
                values: [
                    { prop: 'card', active: true },
                    { prop: 'account', active: true },
                    { prop: 'cash', active: true },
                ],
            },
            {
                name: 'exchangeType',
                values: [
                    { prop: 'ibank', active: true },
                    { prop: 'office', active: true },
                    { prop: 'atm', active: true },
                ],
            },
            {
                name: 'servicePack',
                values: [
                    { prop: 'empty', active: true },
                    { prop: 'premier', active: true },
                    { prop: 'first', active: true },
                ],
            },
        ],
        rateTypes: [
            'base',
            'beznal',
            'premium',
            'first',
            'nal',
        ],
    },

    initConverter() {
        switch (this.props.mode) {
            case 'currency':
                switch (this.props.ratesType) {
                    case 'base':
                    case 'nal':
                        sessionStorage.widgetRatesPreset = 'NOCARD';
                        break;
                    case 'beznal':
                        sessionStorage.widgetRatesPreset = 'CARD';
                        break;
                    case 'premium':
                        sessionStorage.widgetRatesPreset = 'PREMIER';
                        break;
                    case 'first':
                        sessionStorage.widgetRatesPreset = 'FIRST';
                        break;
                    default:
                        this.utils.log('warn', 'bad ratesType');
                }

                break;

            case 'metal':
                sessionStorage.widgetRatesPreset = 'METAL';
                break;

            case 'converter':
                let newParams = {};
                let newType;
                const getParams = (so, de, ex, se) => ({
                    sourceCode: this.converter.params[0].values[so].prop,
                    destinationCode: this.converter.params[1].values[de].prop,
                    exchangeType: this.converter.params[2].values[ex].prop,
                    servicePack: this.converter.params[3].values[se].prop,
                });

                const preset = sessionStorage.widgetRatesPreset;

                switch (preset) {
                    case 'NOCARD': // aka "nal/beznal"
                        newParams = getParams(2, 2, 1, 0);
                        newType = 'nal';
                        break;

                    case 'PREMIER':
                        newParams = getParams(1, 1, 1, 1);
                        newType = 'premium';
                        break;

                    case 'FIRST':
                        newParams = getParams(1, 1, 1, 2);
                        newType = 'first';
                        break;

                    case 'CARD': // aka "UKO"
                    case 'INDEX':
                    case 'METAL':
                    case undefined:
                        newParams = getParams(0, 1, 0, 0);
                        newType = 'beznal';
                        break;

                    default:
                        this.utils.log('warn', 'unknown preset');

                        newParams = getParams(0, 1, 0, 0);
                        newType = 'beznal';
                }

                // Костыль чтобы успели проставиться до того, как пойдут первые запросы.
                this.state.converterParams = newParams;
                this.state.ratesType = newType;

                this.converter.params.reduce((combinations, param) => {
                    param.values.forEach(value => {
                        value.active = combinations[value.prop];
                    });
                    return combinations[newParams[param.name]];
                }, this.converter.combinations);

                break;

            default:
                this.utils.log('warn', 'bad widget mode');
        }
    },

    setConverterParams(params) {
        const param = Object.keys(params)[0];
        const value = params[param];

        const paramOrder = this.converter.params.findIndex(param1 => param1.name === param);
        const curParams = this.state.converterParams;

        if (paramOrder === -1) {
            this.utils.log('warn', 'unknown params');
            return;
        }

        let availableCombinations;
        let finalType;

        const checkCombination = comb => (!comb ? null : Object.keys(comb));

        switch (param) {
            case 'sourceCode':
                availableCombinations = checkCombination(this.converter.combinations[value]);
                break;

            case 'destinationCode':
                availableCombinations = checkCombination(this.converter.combinations[curParams.sourceCode][value]);
                break;

            case 'exchangeType':
                availableCombinations = checkCombination(this.converter.combinations[curParams.sourceCode][curParams.destinationCode][value]);
                break;

            case 'servicePack':
                finalType = this.converter.combinations[curParams.sourceCode][curParams.destinationCode][curParams.exchangeType][value];
                if (typeof finalType === 'undefined') {
                    finalType = null;
                }
                break;

            default:
        }

        if (availableCombinations === null || finalType === null) {
            // selected param combination is invalid (clicked the grayed out option)
            return;
        }

        const nextSection = this.converter.params[paramOrder + 1];

        if (nextSection) {
            nextSection.values.forEach(el => {
                if (availableCombinations.includes(el.prop)) {
                    el.active = true;
                } else {
                    el.active = false;

                    if (curParams[nextSection.name] === el.prop) {
                        // wrong parameter is selected for the current combination, setting to the first valid
                        params[nextSection.name] = availableCombinations[0];
                    }
                }
            });
        } else {
            this.setState({ ratesType: this.converter.rateTypes[finalType] }, () => {
                this.requestCurrent();
            });
        }

        this.setState({
            converterParams: {
                ...this.state.converterParams,
                ...params,
            },
        }, () => {
            if (nextSection) {
                // if next params section exists, recursively set them all
                this.setConverterParams({
                    [nextSection.name]: this.state.converterParams[nextSection.name],
                });
            }
        });
    },

    drawPlot(code) {
        this.actions.drawPlot(code ? [].concat(code) : this.utils.getCodes('checked'));
    },

    requestConversion() {
        this.actions.requestConversion();
    },

    requestDated() {
        // as soon as new ranges arrive this will be called
        // don't call this method directly! ranges must be requested first
        this.actions.requestDated();
    },

    requestRanges() {
        this.actions.requestRanges();
    },

    requestCurrent() {
        this.actions.requestCurrent();
    },

    updateConverterResult() {
        this.refs.Aside.refs.Result.scrollToResult();
    },

    print(id) {
        this.setState({ printSection: id }, () => {
            $(document.body).addClass('print-rates');
            this.drawPlot();
            $('#plot-' + id).find('.jqplot-table-legend-swatch-outline div').each(function() {  // eslint-disable-line func-names
                const width = this.clientWidth;
                const height = this.clientHeight;
                const fill = this.style.backgroundColor;
                $(this)
                    .hide()
                    .after('<svg width="{0}" height="{1}"><rect width="{2}" height="{3}" fill="{4}"/></svg>'.format(
                        width,
                        height,
                        width,
                        height,
                        fill
                    ));
            });
        });
    },

    printStart() {
        window.print();
    },

    printClose() {
        $(document.body).removeClass('print-rates');
        this.drawPlot();
        this.setState({ printSection: null });
    },

    initUtils() {
        return {
            getCheckedRange: code => {
                if (this.state.data[code].ranges) {
                    return this.state.data[code].ranges.filter(range => range.checked)[0].amountFrom;
                }

                return undefined;
            },

            getCodes: (property, inverse, dontSort) => {
                const data = this.state.data;

                const codes = Object.keys(data).filter(code => (
                    inverse ? !data[code][property] : data[code][property]
                ));

                // sorting is enabled by default if not told otherwise
                if (!dontSort) {
                    codes.sort((code1, code2) => data[code1].order - data[code2].order);
                }

                return codes;
            },

            capitalize(str) {
                return str.replace(this.regExp.word, char => char.toUpperCase());
            },

            regExp: {
                nonDigits: /\D/g,
                thousands: /\B(?=(\d{3})+(?!\d))/g,
                delimiters: /[.,]/,
                commas: /,/g,
                spaces: /\s/g,
                word: /\w/,
            },

            format(x) {
                if (typeof x === 'string') {
                    x = x.replace(this.regExp.commas, '.').replace(this.regExp.spaces, '');
                }

                if ($.isNumeric(x)) {
                    x = parseFloat(x).toFixed(2).replace('.', ',');

                    return x < 1000 ? x : x.replace(this.regExp.thousands, ' ');
                }

                return '\u2014';
            },

            log(...args) {
                let firstArg = args[0];
                if (firstArg === 'warn' || firstArg === 'error' || firstArg === 'debug') {
                    args.shift();
                } else {
                    firstArg = 'log';
                }

                if (typeof args[0] === 'string') {
                    // for string interpolation to work
                    args[0] = 'Rates: ' + args[0];
                } else {
                    args = ['Rates:'].concat(args);
                }
                console[firstArg](...args);
            },
        };
    },

    plugins: {
        select: sbrPluginSelect,
        popup: sbrPluginPopup,
    },
});

export default Rates;
