import React from 'react';
import Modal from 'react-bootstrap/lib/Modal';

import './table-view.css';
import urls from '../../urls';

const { tools } = SBT.TOOLBOX;
const { moment, $ } = window;

const RatesTableView = React.createClass({
    componentDidMount() {
        $('body').addClass('modal-open');
        $(window).on('resize.tableView', this.resizeTable);
        this.resizeTable();
    },

    resizeTable() {
        if (this.refs.table && this.refs.tableContainer) {
            // minus overlay margin from both sides, minus table bottom margin
            const spaceLeft = window.innerHeight - 40 * 2 - this.refs.table.offsetTop - 40;
            this.refs.tableContainer.style.maxHeight = spaceLeft + 'px';
        }
    },

    componentWillUnmount() {
        $('body').removeClass('modal-open');
        $(window).off('resize.tableView', this.resizeTable);
    },

    render() {
        const Rates = this.props.Rates;
        const data = Rates.state.data[Rates.state.tableView];
        let lastDate;
        let recordCounter = 0;
        let limitReached = false;

        return (
            <Modal
                show={true}
                className="rates-table-view"
                keyboard={true}
                onCloseClick={Rates.hideTableView}
            >
                <div className="rates-table-view-close" onClick={Rates.hideTableView}>
                    <span>{Rates.props.dict.tableViewClose}</span>
                </div>
                <h2>{Rates.props.dict.tableView + ', ' + (Rates.props.mode === 'metal' ? data.name : data.isoName)}</h2>
                <a
                    className="rates-table-view-download"
                    href={
                        tools.concatPipedURL(urls.xls, {
                            currencyCode: Rates.state.tableView,
                            fromDate: Rates.state.fromDate,
                            toDate: Rates.state.toDate,
                            regionId: Rates.props.regionId,
                            categoryCode: Rates.state.ratesType,
                            rangesAmountFrom: data.ranges.map(function(el) {
                                return el.amountFrom;
                            }),
                            lang: Rates.props.language,
                        })
                    }
                >
                    {Rates.props.dict.tableViewDownload}
                </a>
                <div ref="tableContainer" className="table-container">
                    <table ref="table">
                        <thead>
                            <tr>
                                {[
                                    Rates.props.dict.tableViewDate,
                                    Rates.props.dict.tableViewTime,
                                    Rates.props.dict.tableViewAmount,
                                    Rates.props.dict.tableViewFrom,
                                    Rates.props.dict.tableViewTo,
                                    Rates.props.dict.tableViewBuy,
                                    Rates.props.dict.tableViewSell,
                                ].map((columnTitle, ct) => <th key={ct}>{columnTitle}</th>)}
                            </tr>
                        </thead>
                        <tbody>
                            {data.ratesDated.map(function(el, i) {
                                const newRecord = el.activeFrom !== lastDate;
                                lastDate = el.activeFrom;

                                if (limitReached || (newRecord && ++recordCounter > 200)) {
                                    limitReached = true;
                                    return null;
                                }

                                return (
                                    <tr className={newRecord ? 'rates-record' : null} key={i}>
                                        <td>{newRecord ? moment(lastDate).format(Rates.props.dateFormat) : null}</td>
                                        <td>{newRecord ? moment(lastDate).format(Rates.props.timeFormat) : null}</td>
                                        <td>{newRecord ? data.scale : null}</td>
                                        <td>{$.isNumeric(el.rangeFrom) ? el.rangeFrom : '\u2014'}</td>
                                        <td>
                                            {
                                                $.isNumeric(el.rangeTo) && (el.rangeTo !== 999999999999.99) ?
                                                    el.rangeTo : '\u2014'
                                            }
                                        </td>
                                        <td>{Rates.utils.format(el.buyValue)}</td>
                                        <td>{Rates.utils.format(el.sellValue)}</td>
                                    </tr>
                                );
                            })}
                        </tbody>
                    </table>
                </div>
            </Modal>
        );
    },
});

export default RatesTableView;
