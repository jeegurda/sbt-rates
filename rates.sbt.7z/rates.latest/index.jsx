import React from 'react';

import Rates from './components/rates/rates';

const { tools } = window.SBT.TOOLBOX;

export default function renderWidget(widgetSettings, widgetPreferences) {
    const mode = widgetPreferences.mode || 'currency';
    const props = {
        // widget mode: 'metal' or 'currency' or 'converter'
        mode,
        dict: {
            loading: '',
            currentAmount: tools.getLanguage() === 'ru' ? 'Единица' : 'Unit',
            exchangeNote: `
               Обмен наличной валюты: Фунт стерлингов Соединенного королевства, Швейцарский франк,
               Японская йена осуществляется не во всех отделениях.
               Полный список отделений можете посмотреть в разделе "{0}"
            `,
            exchangeNoteLinkText: 'Наличная валюта',
            showConverter: 'Показать конвертер',
            hideConverter: 'Скрыть конвертер',
            ...widgetPreferences,
            ...widgetSettings,

        },
        // region (77 for Moscow)
        regionId: tools.getRegion(),
        // language: 'en' or 'ru'
        language: tools.getLanguage(),
        // rates type: 'base' or 'beznal' or 'premium' or 'first'
        ratesType: widgetPreferences.type || 'base',
        // date format for moment.js
        dateFormat: 'DD.MM.YYYY',
        // time format for moment.js
        timeFormat: 'HH:mm',
        // selected period: 'month' or 'quarter' or 'halfyear' or 'year'
        // if set to 'custom', default period equals to a week
        period: mode === 'metal' ? 'halfyear' : 'custom',
        // converter source currency code ('840' for USD, '' for RUR)
        sourceCurrencyCode: '',
        // converter destination currency code (same code format as source)
        destCurrencyCode: '840',
        // converter destination currency, used for display only
        destinationCurrency: 'RUB',
        // converter destination currency in short format, used for dispay only
        destinationCurrencyShort: 'р.',
        // value in converter input by default, using 1 in other modes (for current rates),
        // must be a string
        converterAmount: mode === 'converter' ? '100' : '1',
        // currency codes that are allowed for 'first' and 'premium' services
        premiumServiceAllowedCodes: ['840', '978'],
        // currencies with limited exchange offices (a warning will be shown)
        // GBP, CHF, JPG
        limitedExchangeCodes: ['826', '756', '392'],
        // default codes for different widget modes
        // set 'checked' property to true for code to be checked by default in the filter
        // Note: only one property is allowed for 'converter' mode (sourceCurrencyCode is used)
        // format: { 'CODE': {checked: true|false}, ... }
        get codes() {
            if (this.mode === 'metal') {
                return {
                    A33: { checked: true },
                    A76: { checked: true },
                    A98: { checked: true },
                    A99: { checked: true },
                };
            }

            if (this.mode === 'currency') {
                if (this.ratesType === 'premium' || this.ratesType === 'first') {
                    const codeHashes = {};
                    this.premiumServiceAllowedCodes.forEach(code => {
                        codeHashes[code] = { checked: true };
                    });
                    return codeHashes;
                }

                return {
                    840: { checked: true },
                    978: { checked: false },
                };
            }

            if (this.mode === 'converter') {
                return {
                    [this.sourceCurrencyCode || this.destCurrencyCode]: { checked: true }
                };
            }

            return null;
        },
    };

    return <Rates {...props} />;
}
