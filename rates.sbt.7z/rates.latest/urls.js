const SHORT_CACHE_PIPE_URL = '/portalserver/proxy/?pipe=shortCachePipe&url=';

function pipe(url) {
    return SHORT_CACHE_PIPE_URL + encodeURIComponent(url);
}

export default {
    info: pipe('http://localhost/rates-web/rateService/rate/currency'),
    ranges: pipe('http://localhost/rates-web/rateService/rate/ranges'),
    current: pipe('http://localhost/rates-web/rateService/rate/current'),
    rates: pipe('http://localhost/rates-web/rateService/rate'),
    convert: pipe('http://localhost/rates-web/rateService/rate/conversion'),
    xls: pipe('http://localhost/rates-web/rateService/rate/xls'),
};
