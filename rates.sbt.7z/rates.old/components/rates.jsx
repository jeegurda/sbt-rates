if (!Array.prototype.map) {
    throw new Error('This browser doesn\'t support ES5');
}

'use strict';

require('../../libs/jquery.jqplot.min');
require('../../libs/jqplot.cursor.min');
require('../../libs/jqplot.dateAxisRenderer.min');
require('../../libs/jqplot.enhancedLegendRenderer.min');
require('../../libs/jqplot.highlighter.min');
require('../../libs/jquery-ui-timepicker-addon');

var RatesAside = require('../compiled/ratesAside');
var RatesCurrent = require('../compiled/ratesCurrent');
var RatesTabs = require('../compiled/ratesTabs');
var RatesDetails = require('../compiled/ratesDetails');
var RatesTableView = require('../compiled/ratesTableView');

var RatesWidget = React.createClass({
    DOM: {},
    urls: require('./../../urls.js'),
    tabs: [],
    hideTableView: function() {
        this.setState({
            tableView: null
        });
    },
    showTableView: function(code) {
        this.setState({
            tableView: code
        });
    },
    componentWillMount: function() {
        this.utils = this.utils();
    },
    changePeriod: function(newPeriod) {
        var fromDate;
        var dateFormat = this.props.dateFormat;
        var today = moment();

        if (newPeriod !== 'custom') {
            if (newPeriod === 'month') {
                fromDate = moment().subtract(1, 'month').format(dateFormat);
            } else if (newPeriod === 'halfyear') {
                fromDate = moment().subtract(6, 'month').format(dateFormat);
            } else if (newPeriod === 'quarter') {
                fromDate = moment().subtract(1, 'quarter').format(dateFormat);
            } else if (newPeriod === 'year') {
                fromDate = moment().subtract(1, 'year').format(dateFormat);
            } else {
                this.utils.log('error', 'Rates: unknown period literal');
            }

            this.setState({
                fromDate: fromDate,
                toDate: today.format(dateFormat)
            });
        }

        this.setState({
            period: newPeriod
        });
    },
    validateInput: function(e) {
        var self = this;
        var inputType = e.target.getAttribute('data-property');

        if (self.state.invalidFields[inputType]) {
            var newState = {};
            newState[inputType] = self.lastValidValue;
            var newInvalidFields = {};
            newInvalidFields[inputType] = false;
            newState.invalidFields = _.assign({}, self.state.invalidFields, newInvalidFields);

            self.setState(newState);
        }
        self.lastValidValue = null;
    },
    lastValidValue: null,
    changeDate: function(e) {
        var inputType = e.target.getAttribute('data-property');
        var value = e.target.value;
        var self = this;
        var isDateInvalid = function(dateString) {
            // using D.M.YYYY allows '1' as well as '01' for days/months
            return !moment(dateString, 'D.M.YYYY', true).isValid();
        };
        var parseDate = function(dateString) {
            return moment(dateString, 'D.M.YYYY').toDate().getTime();
        };
        var newInvalidFields = {};
        var validate = function(func) {
            if (func()) {
                newInvalidFields[inputType] = true;
            } else {
                newInvalidFields[inputType] = false;
            }
        };

        switch(inputType) {
            case 'fromDate':
                validate(function() {
                    return isDateInvalid(value) ||
                        parseDate(value) < parseDate(self.props.dict.dataAvailabilityDate) ||
                        parseDate(value) > parseDate(self.state.toDate);
                });
            break;
            case 'toDate':
                validate(function() {
                    return isDateInvalid(value) ||
                        parseDate(value) < parseDate(self.state.fromDate) ||
                        parseDate(value) > (new Date).getTime();
                });
            break;
            case 'detailedDate':
                validate(function() {
                    return isDateInvalid(value) ||
                        parseDate(value) < parseDate(self.props.dict.dataAvailabilityDate) ||
                        parseDate(value) > (new Date).getTime();
                });
            break;
            default:
                this.utils.log('warn', 'Bad date type');
        }

        if (this.lastValidValue === null) {
            this.lastValidValue = this.state[inputType];
        }

        var newState = {};
        newState[inputType] = e.target.value;
        newState.invalidFields = _.assign({}, this.state.invalidFields, newInvalidFields);

        this.setState(newState);
    },
    onDatedLoaded: function() {
        this.drawPlot();
    },
    onRangesLoaded: function() {
        this.requestDated();
    },
    initDatepicker: function(el) {
        var self = this;
        if (!el) {
            return;
        }

        el = el.getDOMNode();
        var inputType = el.getAttribute('data-property');
        this.DOM[inputType] = el;
        var $el = $(el);

        var datepickerOpts = {
            changeYear: true,
            yearRange: "2000:2100",
            minDate: moment(this.props.dict.dataAvailabilityDate, this.props.dateFormat).toDate(),
            maxDate: new Date
        };

        if (inputType === 'converterDate') {
            $el.datetimepicker(_.assign(datepickerOpts, {
                controlType: 'select',
                oneLine: true,
                timeFormat: this.props.timeFormat,
                timeText: this.props.dict.filterConverterDate,
                closeText: this.props.dict.filterConverterDateSelect,
                showButtonPanel: false,
                stepMinute: 5,
                onSelect: function(date) {
                    var newState = {
                        period: 'custom'
                    };

                    newState[inputType] = date;
                    self.setState(newState);
                }
            }));
        } else {
            $el.datepicker(_.assign(datepickerOpts, {
                beforeShow: function() {
                    if (inputType === 'fromDate') {
                        $el
                            .datetimepicker('option', 'maxDate', moment(self.state.toDate, self.props.dateFormat).toDate())
                            .datetimepicker('option', 'minDate', moment(self.props.dict.dataAvailabilityDate, self.props.dateFormat).toDate());
                    } else if (inputType === 'toDate') {
                        $el
                            .datetimepicker('option', 'minDate', moment(self.state.fromDate, self.props.dateFormat).toDate())
                            .datetimepicker('option', 'maxDate', new Date);
                    }
                    // detailedDate datepicker should be restricted by the options, no need to check it
                },
                onSelect: function(date) {
                    var newState = {
                        period: 'custom'
                    };

                    newState[inputType] = date;
                    self.setState(newState);
                }
            }));
        }
    },
    componentDidMount: function() {
        var self = this;

        $(document.body)
            .on('click', '.filter-datepicker-trigger', function() {
                $(this).prev('input').focus();
            })
            .on('click', '.converter-datepicker-hide', function() {
                $(self.DOM.converterDate).datepicker('hide');
            });

        if (this.props.mode === 'metal') {
            this.tabs = ['history'];
        } else {
            this.tabs = ['history', 'table'];
        }

        if (this.state.period === 'custom') {
            this.setState({
                fromDate: moment().subtract(1, 'week').format(this.props.dateFormat),
                toDate: moment().format(this.props.dateFormat)
            });
        }
        this.changePeriod(this.state.period);

        this.actions = require('../../ratesActions').call(this);

        this.initConverter();

        this.actions.requestInfo();
        this.actions.requestCurrent(true);
        this.requestDetails();
    },
    converter: {
        params: [
            {
                name: 'sourceCode',
                values: [{prop: 'card', active: true}, {prop: 'account', active: true}, {prop: 'cash', active: true}]
            },
            {
                name: 'destinationCode',
                values: [{prop: 'card', active: true}, {prop: 'account', active: true}, {prop: 'cash', active: true}]
            },
            {
                name: 'exchangeType',
                values: [{prop: 'ibank', active: true}, {prop: 'office', active: true}, {prop: 'atm', active: true}]
            },
            {
                name: 'servicePack',
                values: [{prop: 'empty', active: true}, {prop: 'premier', active: true}, {prop: 'first', active: true}]
            }
        ],
        rateTypes: [
            'base',
            'beznal',
            'premium',
            'first'
        ],
        combinations: require('../../combinations')
    },
    initConverter: function() {
        switch(this.props.mode) {
            case 'currency':

                switch(this.props.ratesType) {
                    case 'base':
                        sessionStorage.widgetRatesPreset = 'NOCARD';
                    break;
                    case 'beznal':
                        sessionStorage.widgetRatesPreset = 'CARD';
                    break;
                    case 'premium':
                        sessionStorage.widgetRatesPreset = 'PREMIER';
                    break;
                    case 'first':
                        sessionStorage.widgetRatesPreset = 'FIRST';
                    break;
                    default:
                        this.utils.log('warn', 'bad ratesType');
                }

            break;
            case 'metal':
                sessionStorage.widgetRatesPreset = 'METAL';
            break;
            case 'converter':
                var self = this;
                var newParams = {};
                var newType;
                var getParams = function(so, de, ex, se) {
                    return {
                        sourceCode: self.converter.params[0].values[so].prop,
                        destinationCode: self.converter.params[1].values[de].prop,
                        exchangeType: self.converter.params[2].values[ex].prop,
                        servicePack: self.converter.params[3].values[se].prop
                    };
                };

                var preset = sessionStorage.widgetRatesPreset;

                switch(preset) {
                    case 'NOCARD': // aka "nal/beznal"
                        newParams = getParams(2, 2, 1, 0);
                        newType = 'base';
                    break;
                    case 'PREMIER':
                        newParams = getParams(1, 1, 1, 1);
                        newType = 'premium';
                    break
                    case 'FIRST':
                        newParams = getParams(1, 1, 1, 2);
                        newType = 'first';
                    break;
                    case 'CARD': // aka "UKO"
                    case 'INDEX':
                    case 'METAL':
                    case undefined:
                        newParams = getParams(0, 1, 0, 0);
                        newType = 'beznal';
                    break;
                    default:
                        this.utils.log('warn', 'unknown preset');

                        newParams = getParams(0, 1, 0, 0);
                        newType = 'beznal';
                }

                this.setState({
                    converterParams: newParams,
                    ratesType: newType
                });
            break;
            default:
                this.utils.log('warn', 'bad widget mode');
        }
    },
    setConverterParams: function(params) {
        var self = this;

        var param = Object.keys(params)[0];
        var value = params[param];

        var paramOrder = _.findIndex(this.converter.params, {name: param});
        var curParams = this.state.converterParams;

        if (!~paramOrder) {
            this.utils.log('warn', 'unknown params');
            return;
        }

        var availableCombinations;
        var finalType;

        var checkCombination = function(comb) {
            if (!comb) {
                return null;
            } else {
                return Object.keys(comb);
            }
        };

        switch(param) {
            case 'sourceCode':
                availableCombinations = checkCombination(this.converter.combinations[value]);
            break;
            case 'destinationCode':
                availableCombinations = checkCombination(this.converter.combinations[curParams.sourceCode][value]);
            break;
            case 'exchangeType':
                availableCombinations = checkCombination(this.converter.combinations[curParams.sourceCode][curParams.destinationCode][value]);
            break;
            case 'servicePack':
                finalType = this.converter.combinations[curParams.sourceCode][curParams.destinationCode][curParams.exchangeType][value];
                if (typeof finalType === 'undefined') {
                    finalType = null;
                }
            break;
        }

        if (availableCombinations === null || finalType === null) {
            // selected param combination is invalid (clicked the grayed out option)
            return;
        }

        var nextSection = this.converter.params[paramOrder + 1];

        if (nextSection) {
            nextSection.values.forEach(function(el) {
                if (~availableCombinations.indexOf(el.prop)) {
                    el.active = true;
                } else {
                    el.active = false;

                    if (curParams[nextSection.name] === el.prop) {
                        // wrong parameter is selected for the current combination, setting to the first valid
                        params[nextSection.name] = availableCombinations[0];
                    }
                }
            });

        } else {
            this.setState({
                ratesType: this.converter.rateTypes[finalType]
            }, function() {
                self.requestCurrent(true);
            });
        }

        this.setState({
            converterParams: _.assign({}, this.state.converterParams, params)
        }, nextSection && function() {
            // if next params section exists, recursively set them all
            var obj = {};
            obj[nextSection.name] = self.state.converterParams[nextSection.name];
            self.setConverterParams(obj);
        });
    },
    drawPlot: function(code) {
        this.actions.drawPlot(code ? [].concat(code) : this.utils.getCodes('checked'));
    },
    requestConversion: function() {
        this.actions.requestConversion();
    },
    requestDated: function() {
        // as soon as new ranges arrive this will be called
        // don't call this method directly! ranges must be requested first
        this.actions.requestDated();
    },
    requestRanges: function() {
        this.actions.requestRanges();
    },
    requestCurrent: function(noDate) {
        this.actions.requestCurrent(noDate);
    },
    requestDetails: function() {
        var viewMode = this.state.viewMode;
        if (viewMode === 'history') {
            this.requestRanges();
        } else if (viewMode === 'table') {
            this.requestCurrent();
        }
    },
    updateConverterResult: function() {
        this.refs.Aside.refs.Result.scrollToResult();
    },
    print: function(id) {
        var self = this;
        var newState = {};

        self.setState(_.assign(newState, {
            printSection: id
        }), function() {
            $('#plot-' + id).find('.jqplot-table-legend-swatch-outline div').each(function() {
                var width = this.clientWidth;
                var height = this.clientHeight;
                var fill = this.style.backgroundColor;
                $(this)
                    .hide()
                    .after('<svg width="{0}" height="{1}"><rect width="{2}" height="{3}" fill="{4}"/></svg>'.format(
                        width,
                        height,
                        width,
                        height,
                        fill
                    ));
            });

            $(document.body).addClass('print-rates');
            window.print();
            $(document.body).removeClass('print-rates');
            self.setState({
                printSection: null
            });
        });
    },
    getInitialState: function() {
        var props = this.props;

        return {
            error: {
                info: false
            },
            cachedParams: {
                converter: {},
                dated: {},
                datedBody: {},
                detailed: {},
                ranges: {}
            },
            invalidFields: {},
            ratesCurrentLatestChange: 0,
            converterAmount: props.converterAmount,
            get converterDate() {
                var today = (new Date);
                var hours = today.getHours();
                var minutes = Math.floor(today.getMinutes() / 5) * 5;

                return moment().format(props.dateFormat) + ' ' + (hours < 10 ? '0' + hours : hours) + ':' + (minutes < 10 ? '0' + minutes : minutes);
            },
            converterDateSelect: 'current',
            converterFrom: props.sourceCurrencyCode,
            converterResult: {
                amount: '',
                value: null,
                from: '',
                to: '',
                valid: false
            },
            converterTo: props.destCurrencyCode,
            converterParams: {},
            data: $.extend(true, {}, props.codes),
            detailedDate: moment().format(props.dateFormat),
            fromDate: null,
            period: props.period,
            toDate: null,
            viewMode: props.viewMode,
            ratesType: props.ratesType
        };
    },
    render: function() {
        var widgetContent;

        if (this.state.error.info) {
            widgetContent = (
                <div>{this.props.dict.loadingError}</div>
            )
        } else {
            if (this.utils.getCodes('name').length) {
                widgetContent = [
                    <RatesCurrent Rates={this} ref="Current" key="0"/>,
                    <RatesAside Rates={this} ref="Aside" key="1"/>,
                    <RatesTabs Rates={this} ref="Tabs" key="2"/>,
                    <RatesDetails Rates={this} ref="Details" key="3"/>,
                    this.state.tableView && <RatesTableView Rates={this} ref="Modal" key="4"/>
                ];
            } else {
                widgetContent = <div>{this.props.dict.loading}</div>;
            }
        }

        return (
            <div className="widget-rates">
                {widgetContent}
            </div>
        )
    },
    utils: function() {
        var self = this;

        return {
            getRangesDescription: function(ranges) {
                return Object.keys(ranges).map(function(el) {
                    return ranges[el].amountFrom;
                }).sort(function(a, b) {
                    return a - b;
                }).map(function(el, i, arr) {
                    var nextMax = el;
                    for (var j = i; j < arr.length; j++) {
                        if (arr[j] > el) {
                            nextMax = arr[j];
                            break;
                        }
                    }
                    if (nextMax === el) {
                        return self.props.dict.detailsRangeFrom + ' ' + el;
                    } else {
                        return el + '-' + nextMax;
                    }
                });
            },
            getCheckedRange: function(code) {
                if (self.state.data[code].ranges) {
                    return self.state.data[code].ranges.filter(function(range) {
                        return range.checked;
                    })[0].amountFrom;
                }
            },
            getCodes: function(property, inverse, dontSort) {
                var codes = Object.keys(self.state.data).filter(function(code) {
                    return inverse ? !self.state.data[code][property] : self.state.data[code][property];
                });

                // sorting is enabled by default if not told otherwise
                if (!dontSort) {
                    codes = codes.sort(function(a, b) {
                        return self.state.data[a].order - self.state.data[b].order;
                    });
                }

                return codes;
            },
            capitalize: function(str) {
                return str.replace(this.regExp.word, function(m) {
                    return m.toUpperCase()
                });
            },
            regExp: {
                nonDigits: /\D/g,
                thousands: /\B(?=(\d{3})+(?!\d))/g,
                delimiters: /[.,]/,
                commas: /,/g,
                spaces: /\s/g,
                word: /\w/
            },
            format: function(x) {
                if (typeof x === 'string') {
                    x = x.replace(this.regExp.commas, '.').replace(this.regExp.spaces, '');
                }

                if ($.isNumeric(x)) {
                    x = parseFloat(x).toFixed(2).replace('.', ',');

                    return x < 1000 ? x : x.replace(this.regExp.thousands, ' ');
                } else {
                    return '\u2014';
                }
            },
            log: function() {
                var args = Array.prototype.slice.call(arguments);
                var firstArg = args[0];
                if (firstArg === 'warn' || firstArg === 'error' || firstArg === 'debug') {
                    args.shift();
                } else {
                    firstArg = 'log';
                }

                if (typeof args[0] === 'string') {
                    // for string interpolation to work
                    args[0] = 'Rates: ' + args[0];
                } else {
                    args = ['Rates:'].concat(args);
                }
                console[firstArg].apply(console, args);
            }
        }
    },
    plugins: {
        select: require('../../libs/SBR.plugin.Select'),
        popup: require('../../libs/SBR.plugin.Popup')
    }
});

module.exports = RatesWidget;