'use strict';

var RatesAside = React.createClass({
    changeCodes: function(e) {
        var Rates = this.props.Rates;
        var target = e.target;

        // if it's not the last checked checkbox
        if (Rates.utils.getCodes('checked').length !== 1 || target.checked) {
            var newStateData = _.assign({}, Rates.state.data);
            newStateData[target.name].checked = target.checked;

            Rates.setState({
                data: newStateData
            }, function() {
                Rates.actions.requestCurrent(true);
            });
        }
    },
    changeConverterDate: function(e) {
        this.props.Rates.setState({
            converterDateSelect: e.target.value
        });
    },
    changeConverterParams: function(e) {
        var obj = {};
        obj[e.target.name] = e.target.value;

        // triggers setState!
        this.props.Rates.setConverterParams(obj);
    },
    changePeriod: function(e) {
        this.props.Rates.changePeriod(e.target.value);
    },
    updateDetails: function() {
        this.props.Rates.requestDetails();
    },
    updateConverter: function(e) {
        if (e.type === 'submit') {
            e.preventDefault();
        }
        var Rates = this.props.Rates;

        if (parseInt(
            Rates.state.converterAmount.replace(Rates.utils.regExp.commas, '.').replace(Rates.utils.regExp.spaces, '')
        ) > 0) {
            this.props.Rates.requestConversion();
        } else {
            Rates.DOM.converterAmount.focus();
        }
    },
    changeDate: function(e) {
        this.props.Rates.changeDate(e);
    },
    selectCode: function(e) {
        var Rates = this.props.Rates;
        var target = e.target;
        var value = target.value;
        var targetName = target.name;
        var selectToUpdate;

        var handleSelect = function(curSelect, otherSelect) {
            var newState = _.assign({}, Rates.state);

            newState.data[Rates.state.converterFrom || Rates.state.converterTo].checked = false;

            if (value === Rates.state[otherSelect]) {
                newState[otherSelect] = Rates.state[curSelect];
                selectToUpdate = otherSelect;
            }
            newState[curSelect] = value;

            // using code in a 'from' property as a current code IF it's not the default currency
            // using 'to' property otherwise
            newState.data[newState.converterFrom || newState.converterTo].checked = true;

            Rates.setState(newState, function() {
                Rates.actions.requestCurrent(true);
                if (selectToUpdate) {
                    $(Rates.DOM[selectToUpdate]).trigger('update');
                }
            });
            Rates.DOM.converterAmount.focus();
            Rates.DOM.converterAmount.setSelectionRange(100, 100);
        };

        if (targetName === 'converterFrom') {
            handleSelect('converterFrom', 'converterTo');
        } else if (targetName === 'converterTo') {
            handleSelect('converterTo', 'converterFrom');
        }
    },
    initSelect: function(el, preCallback) {
        var Rates = this.props.Rates;
        if (!el || el.hasAttribute('data-select-initialized')) {
            return;
        }
        preCallback && preCallback();
        Rates.DOM[el.name] = el;
        Rates.plugins.select.call($(el), {
            popup: Rates.plugins.popup,
            allowClickOnActive: 'visual',
            ctx: Rates
        });
    },
    // counter for currencies which should always appear at the bottom, such as selected ones
    bottomCurrencyOrder: 999,
    selectCurrency: function(e) {
        var Rates = this.props.Rates;
        var target = e.target;
        var newStateData = _.assign({}, Rates.state.data);

        newStateData[target.value].display = true;
        newStateData[target.value].checked = true;
        newStateData[target.value].order = this.bottomCurrencyOrder++;

        Rates.setState({
            data: newStateData
        }, function() {
            target.selectedIndex = -1;
            Rates.actions.requestCurrent(true);
            $(target).trigger('update');
        });
    },
    removingSpace: false,
    onKeyDownAmount: function(e) {
        var target = e.target;
        // if pressed backspace and it's going to remove the space
        if (e.keyCode === 8 && target.value.charAt(target.selectionStart - 1) === ' ') {
            this.removingSpace = true;
        }
    },
    changeAmount: function(e) {
        var Rates = this.props.Rates;
        var target = e.target;
        var value = target.value;
        var delimiterFound = false;
        var delimiter;

        // remember cursor position
        var start = target.selectionStart;
        var end = target.selectionEnd;

        // clear the string from non-digits and excessive delimiters
        var clearString = value.replace(Rates.utils.regExp.nonDigits, function(m) {
            if (!delimiterFound) {
                var match = m.match(Rates.utils.regExp.delimiters);
                if (match) {
                    delimiterFound = true;
                    delimiter = match[0];
                    return match;
                }
            }
            return '';
        });

        // remember how many symbols from user input were cut
        var inputLength = value.length - clearString.length;

        // remove excessive digits
        clearString = clearString.split(delimiter).map(function(p, i) {
            return p.substr(0, i === 0 ? 12 : 2);
        }).join(delimiter);

        // remember string's length to count spaces after
        var lengthBefore = clearString.length;

        // insert spaces
        clearString = clearString.replace(Rates.utils.regExp.thousands, ' ');

        // substract inserted spaces from cursor position
        inputLength = inputLength - (clearString.length - lengthBefore);

        if (this.removingSpace) {
            // remove one position to "jump over" the space (pure usability)
            inputLength++;
            this.removingSpace = false;
        }

        Rates.setState({
            converterAmount: clearString
        }, function() {
            // restore cursor position
            target.setSelectionRange(start - inputLength, end - inputLength);
        });
    },
    componentDidUpdate: function() {
        var Rates = this.props.Rates;

        Rates.initDatepicker(this.refs.filterDatepickerFrom);
        Rates.initDatepicker(this.refs.filterDatepickerTo);
        Rates.initDatepicker(this.refs.filterDatepickerDetailed);
    },
    render: function() {
        var Rates = this.props.Rates;
        var AsideFilterRates = require('../compiled/ratesAsideFilterRates');
        var AsideFilterConverter = require('../compiled/ratesAsideFilterConverter');
        var AsideFilterConverterResult = require('../compiled/ratesAsideFilterConverterResult');
        var filter;

        if (Rates.state.viewMode === 'table') {
            filter = (
                <div className="rates-aside-filter rates-container">
                    <div className="filter-block">
                        <div>
                            <h6>{Rates.props.dict.filterSelectDate}</h6>
                        </div>
                        <div className="filter-block-line">
                            <div className="filter-datepicker input">
                                <input
                                    className={Rates.state.invalidFields.detailedDate && 'invalid' || null}
                                    name="filter-datepicker-detailed"
                                    data-property="detailedDate"
                                    value={Rates.state.detailedDate}
                                    onChange={this.changeDate}
                                    onBlur={Rates.validateInput}
                                    ref="filterDatepickerDetailed"
                                    maxLength="10"
                                />
                                <span className="filter-datepicker-trigger"/>
                            </div>
                        </div>
                    </div>
                    <div className="filter-block filter-block-info">
                        <p>
                            {Rates.props.dict.dataAvailability}
                            <span> </span>
                            {Rates.props.dict['dataAvailabilityDate' + Rates.utils.capitalize(Rates.state.ratesType)]}
                        </p>
                        <button className="button" onClick={this.updateDetails}>{Rates.props.dict.show}</button>
                    </div>
                </div>
            )
        } else if (Rates.state.viewMode === 'history') {
            if (Rates.props.mode === 'converter') {
                filter = [
                    <AsideFilterConverter Rates={Rates} Aside={this} key="0"/>,
                    <AsideFilterConverterResult ref="Result" Rates={Rates} Aside={this} key="1"/>
                ];
            } else {
                filter = <AsideFilterRates Rates={Rates} Aside={this}/>;
            }
        }

        return (
            <aside className="rates-aside">
                {filter}
            </aside>
        )
    }
});

module.exports = RatesAside;