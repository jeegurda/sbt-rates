'use strict';

var AsideFilterConverterResult = React.createClass({
    resultVisible: false,
    resultTransformedOffset: 50, // initial transformed offset
    resultOffset: 25, // additional offset for readability
    scrollToResult: function() {
        if (this.refs.converterResult && this.props.Rates.state.converterResult.valid) {
            var result = this.refs.converterResult.getDOMNode();
            var resultBottom =
                result.getBoundingClientRect().bottom +
                this.resultOffset +
                (this.resultVisible ? 0 : this.resultTransformedOffset);
            var diff = resultBottom - window.innerHeight;

            this.resultVisible = true;

            if (diff > 0) {
                $('html, body').animate({
                    scrollTop: $(window).scrollTop() + diff
                }, 200);
            }
        } else {
            this.resultVisible = false;
        }
    },
    render: function() {
        var Aside = this.props.Aside;
        var Rates = this.props.Rates;

        if ($.isNumeric(Rates.state.converterResult.value) && Rates.state.converterResult.valid) {
            return (
                <div className="converter-result" ref="converterResult">
                    <h3>{Rates.props.dict.filterConverterResult}</h3>
                    <h5>
                        {Rates.utils.format(Rates.state.converterResult.amount)}
                        {Rates.state.converterResult.from ? Rates.state.data[Rates.state.converterResult.from].isoName : Rates.props.destinationCurrency}
                        =
                    </h5>
                    <h4>
                        {Rates.utils.format(Rates.state.converterResult.value)}
                        {Rates.state.converterResult.to ? Rates.state.data[Rates.state.converterResult.to].isoName : Rates.props.destinationCurrency}
                    </h4>
                </div>
            )
        } else {
            return <div></div>
        }
    }
});

module.exports = AsideFilterConverterResult;