'use strict';

var AsideFilterRates = React.createClass({
    componentDidUpdate: function() {
        var currencySelect = this.refs.currencySelect;
        var Aside = this.props.Aside;

        if (currencySelect) {
            currencySelect = currencySelect.getDOMNode();
            Aside.initSelect(currencySelect, function() {
                currencySelect.selectedIndex = -1;
            });
        }

        var Rates = this.props.Rates;

        Rates.initDatepicker(this.refs.filterDatepickerFrom);
        Rates.initDatepicker(this.refs.filterDatepickerTo);
    },
    render: function() {
        var Aside = this.props.Aside;
        var Rates = this.props.Rates;
        var currencySelect;

        // for currency mode and if at least one option isn't selected
        if (
            Rates.state.ratesType !== 'first' &&
            Rates.state.ratesType !== 'premium' &&
            Rates.props.mode === 'currency' &&
            Rates.utils.getCodes('display', true).length
        ) {
            currencySelect = (
                <div className="filter-block filter-block-currency-select">
                    <div>
                        <h6>{Rates.props.dict.filterSelectCurrency}</h6>
                    </div>
                    <select
                        ref="currencySelect"
                        onChange={Aside.selectCurrency}>
                        {Rates.utils.getCodes('display', true).map(function(code, i) {
                            return (
                                <option key={i} value={code}>{Rates.state.data[code].name}</option>
                            )
                        })}
                    </select>
                </div>
            )
        }

        return (
            <div className="rates-aside-filter rates-container">
                <div className="filter-block filter-block-currency-list">
                    <div>
                        <h6>{Rates.props.dict['filter' + Rates.utils.capitalize(Rates.props.mode)]}</h6>
                    </div>
                    {Rates.utils.getCodes('display').map(function(code, i) {
                        return (
                            <label key={i}>
                                <input
                                    type="checkbox"
                                    name={code}
                                    checked={Rates.state.data[code].checked}
                                    onChange={Aside.changeCodes}/>
                                <span className="checkbox"/>
                                <p>{Rates.state.data[code].name}</p>
                            </label>
                        )
                    })}
                </div>
                {currencySelect}
                <div className="filter-block filter-block-period">
                    <div>
                        <h6>{Rates.props.dict.filterPeriod}</h6>
                    </div>
                    {['month', 'halfyear', 'quarter', 'year', 'custom'].map(function(el, i) {
                        return (
                            <label key={i}>
                                <input
                                    type="radio"
                                    name="period"
                                    checked={Rates.state.period === el ? true : false}
                                    value={el}
                                    onChange={Aside.changePeriod}/>
                                <span className="radio"/>
                                <p>
                                    {Rates.props.dict['filter' + Rates.utils.capitalize(el)]}
                                </p>
                            </label>
                        )
                    })}
                </div>
                <div className="filter-block filter-block-period-datepicker">
                    {['from', 'to'].map(function(el, i) {
                        return (
                            <div className="filter-block-line with-caption" key={i}>
                                <p>{Rates.props.dict['filter' + Rates.utils.capitalize(el)]}</p>
                                <div className="filter-datepicker input">
                                    <input
                                        className={Rates.state.invalidFields[el + 'Date'] && 'invalid' || null}
                                        name={'filter-datepicker-' + el}
                                        data-property={el + 'Date'}
                                        value={Rates.state[el + 'Date']}
                                        onChange={Aside.changeDate}
                                        onBlur={Rates.validateInput}
                                        ref={'filterDatepicker' + Rates.utils.capitalize(el)}
                                        maxLength="10"
                                    />
                                    <span className="filter-datepicker-trigger"/>
                                </div>
                            </div>
                        )
                    })}
                </div>
                <div className="filter-block filter-block-info">
                    <p>
                        {Rates.props.dict.dataAvailability}
                        <span> </span>
                        {Rates.props.dict.dataAvailabilityDate}
                    </p>
                    <button className="button" onClick={Aside.updateDetails}>{Rates.props.dict.show}</button>
                </div>
            </div>
        )
    }
});

module.exports = AsideFilterRates;