'use strict';

var RatesCurrent = React.createClass({
    render: function() {
        var self = this;
        var Rates = this.props.Rates;
        var note;
        var exchangeNote;
        var links;
        var mode = Rates.props.mode;
        var ratesType = Rates.state.ratesType;
        var dict = Rates.props.dict;

        if (ratesType === 'first' || ratesType === 'premium') {

            var noteText = dict['currentNoteFragment' + (mode === 'metal' ? 'Metal' : 'Currency')];
            var noteLinkUrl = dict[ratesType + 'Link' + Rates.utils.capitalize(Rates.props.language)];
            var noteLinkText = dict.currentNoteFragmentLink.format(dict['currentNote' + Rates.utils.capitalize(ratesType)]);

            var noteLink = '<a href="{0}" target="_blank">{1}</a>'.format(noteLinkUrl, noteLinkText);

            note = (
                <div className="current-rates-note rates-note">
                    <strong>{dict.currentNoteBold}</strong>
                    <span> </span>
                    <span dangerouslySetInnerHTML={{
                        __html: noteText.format(noteLink)
                    }}></span>
                </div>
            )
        }

        if (
            Rates.state.converterParams.sourceCode === 'cash' &&
            Rates.state.converterParams.destinationCode === 'cash' &&
            (~Rates.props.limitedExchangeCodes.indexOf(Rates.state.converterFrom) ||
            ~Rates.props.limitedExchangeCodes.indexOf(Rates.state.converterTo))
        ) {

            var exchangeNoteLinkUrl = dict['exchangeNoteLink' + Rates.utils.capitalize(Rates.props.language)];
            var exchangeNoteLinkText = dict.exchangeNoteLinkText;

            var exchangeNoteLink = '<a href="{0}" target="_blank">{1}</a>'.format(exchangeNoteLinkUrl, exchangeNoteLinkText);

            exchangeNote = (
                <div className="current-rates-note rates-note">
                    <span dangerouslySetInnerHTML={{
                        __html: dict.exchangeNote.format(exchangeNoteLink)
                    }}></span>
                </div>
            )
        }

        if (mode === 'metal') {
            links = (
                <div className="current-links">
                    <a href={dict['calculatorIncomeLink' + Rates.utils.capitalize(Rates.props.language)]}>
                        {dict.calculatorIncome}
                    </a>
                </div>
            )
        } else if (mode === 'currency') {
            links = (
                <div className="current-links">
                    <a href={dict['calculatorLink' + Rates.utils.capitalize(Rates.props.language)]}>
                        {dict.calculator}
                    </a>
                </div>
            )
        }

        if (Rates.utils.getCodes('checked').some(function(el) {
            return Rates.state.data[el].ratesCurrent;
        })) {
            return (
                <div className="rates-current rates-right">
                    <div className="current-rates rates-container">
                        <div className="current-table">
                            <table>
                                <thead>
                                    <tr>
                                        <th>{dict['current' + (mode === 'metal' ? 'Metal' : 'Currency')]}</th>
                                        <th>{dict.currentAmount}</th>
                                        <th>{dict.currentBuy}</th>
                                        <th>{dict.currentSell}</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {Rates.utils.getCodes('checked').map(function(el, i) {
                                        var item = Rates.state.data[el];
                                        var itemRates = item.ratesCurrent;

                                        // if for some reason checked element wasn't loaded yet (few requests on a slow connection)
                                        if (itemRates) {
                                            var buyClassName = itemRates.buyChange > 0 ?
                                                'rates-up'
                                                :
                                                (itemRates.buyChange < 0 ?
                                                    'rates-down'
                                                    :
                                                    'rates-none');
                                            var sellClassName = itemRates.sellChange > 0 ?
                                                'rates-up'
                                                :
                                                (itemRates.sellChange < 0 ?
                                                    'rates-down'
                                                    :
                                                    'rates-none');
                                            var itemTitle;

                                            if (mode === 'metal') {
                                                itemTitle = item.name;
                                            } else {
                                                itemTitle = [
                                                    item.isoName,
                                                    <em key={1}> / {Rates.props.destinationCurrency}</em>
                                                ]
                                            }

                                            var buyTitle = itemRates.buyChange > 0 ?
                                                (dict.currentIncrease + ': ' + Rates.utils.format(itemRates.buyChange))
                                                :
                                                (itemRates.buyChange < 0 ?
                                                    (dict.currentDecrease + ': ' + Rates.utils.format(itemRates.buyChange))
                                                    :
                                                    null);
                                            var sellTitle = itemRates.sellChange > 0 ?
                                                (dict.currentIncrease + ': ' + Rates.utils.format(itemRates.sellChange))
                                                :
                                                (itemRates.sellChange < 0 ?
                                                    (dict.currentDecrease + ': ' + Rates.utils.format(itemRates.sellChange))
                                                    :
                                                    null);

                                            return (
                                                <tr key={i}>
                                                    <td>{itemTitle}</td>
                                                    <td>{itemRates.scale}</td>
                                                    <td title={buyTitle}>
                                                        <span className={buyClassName}>
                                                            {Rates.utils.format(itemRates.buyValue)}
                                                        </span>
                                                    </td>
                                                    <td title={sellTitle}>
                                                        <span className={sellClassName}>
                                                            {Rates.utils.format(itemRates.sellValue)}
                                                        </span>
                                                    </td>
                                                </tr>
                                            )
                                        }
                                    })}
                                </tbody>
                            </table>
                        </div>
                        <div className="current-info">
                            {dict.currentInfo.format(
                                Rates.props.dict['currentInfo' + Rates.utils.capitalize(mode)],
                                moment(Rates.state.ratesCurrentLatestChange).format(Rates.props.dateFormat + ' H:mm')
                            )}
                        </div>
                    </div>
                    {note}
                    {exchangeNote}
                    {links}
                </div>
            )
        } else {
            return null;
        }
    }
});

module.exports = RatesCurrent;