'use strict';

var RatesDetails = React.createClass({
    componentDidMount: function() {
        var Rates = this.props.Rates;
        var self = this;
        var dontClose = false;

        $(document).on('click', '.rl-range', function() {
            dontClose = true;
        });

        $(document).on('click', function(e) {
            if (e.target.tagName.toLowerCase() !== 'input') {

                // if at least one is open (to not trigger excessive state change)
                if (!dontClose && Rates.utils.getCodes('rangePopupVisible').length) {
                    self.toggleRangePopup(false);
                }
                dontClose = false;
            }
        });
    },
    toggleRangePopup: function(open, curCode) {
        var Rates = this.props.Rates;

        var newStateData = _.assign({}, Rates.state.data);
        Object.keys(newStateData).forEach(function(code) {
            // if true toggle for code and close all, else just close all
            newStateData[code].rangePopupVisible = open ? (curCode === code) : false;
        });

        Rates.setState({
            data: newStateData
        });
    },
    changeRange: function(code, e) {
        var Rates = this.props.Rates;
        var self = this;
        var target = e.target;

        if ($(target).hasClass('checked')) {
            return;
        }

        var newStateData = _.assign({}, Rates.state.data);

        newStateData[code].ranges.forEach(function(range) {
            range.checked = range.amountFrom === parseInt(target.getAttribute('data-range-from'), 10);
        });

        Rates.setState({
            data: newStateData
        }, function() {
            self.toggleRangePopup(false);
            Rates.drawPlot(code);
        });
    },
    changeDate: function(e) {
        this.props.Rates.changeDate(e);
    },
    updateDetails: function() {
        this.props.Rates.requestDetails();
    },
    render: function() {
        var Rates = this.props.Rates;
        var DetailsHistory = require('../compiled/ratesDetailsHistory');
        var DetailsTable = require('../compiled/ratesDetailsTable');
        var details;

        if (Rates.state.viewMode === 'history') {
            details = <DetailsHistory Rates={Rates} Details={this}/>
        } else if (Rates.state.viewMode === 'table') {
            details = <DetailsTable Rates={Rates} Details={this}/>
        }

        return (
            <div className="rates-right">
                {details}
            </div>
        )
    }
});

module.exports = RatesDetails;