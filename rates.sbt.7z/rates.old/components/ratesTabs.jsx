'use strict';

var RatesTabs = React.createClass({
    changeViewMode: function(e) {
        var Rates = this.props.Rates;
        var newMode = e.currentTarget.getAttribute('data-view-mode');

        if (newMode !== Rates.state.viewMode) {
            Rates.setState({
                viewMode: newMode
            }, Rates.requestDetails);
        }
    },
    render: function() {
        var Rates = this.props.Rates;
        var self = this;
        return (
            <ul className="rates-tabs rates-right">
                {Rates.tabs.map(function(c, i) {
                    return (
                        <li
                            className={Rates.state.viewMode === c ? 'active' : ''}
                            key={i}
                            data-view-mode={c}
                            onClick={self.changeViewMode}
                        >
                            <span>{Rates.props.dict['tabMode' + Rates.utils.capitalize(c)]}</span>
                        </li>
                    )
                })}
            </ul>
        )
    }
});

module.exports = RatesTabs;