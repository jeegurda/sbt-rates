'use strict';

var prefix = '/portalserver/proxy/?pipe=shortCachePipe&url=';

var pipeMe = function(url) {
    return prefix + encodeURIComponent(url);
};

module.exports = {
    info: pipeMe('http://localhost/sbt-services/services/rest/rateService/rate/currency'),
    ranges: pipeMe('http://localhost/sbt-services/services/rest/rateService/rate/ranges'),
    current: pipeMe('http://localhost/sbt-services/services/rest/rateService/rate/current'),
    rates: pipeMe('http://localhost/sbt-services/services/rest/rateService/rate'),
    convert: pipeMe('http://localhost/sbt-services/services/rest/rateService/rate/conversion'),
    xls: pipeMe('http://localhost/sbt-services/services/rest/rateService/rate/xls')
};