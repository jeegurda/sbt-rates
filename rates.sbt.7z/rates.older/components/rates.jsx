if (!Array.prototype.map) {
    throw new Error('This browser doesn\'t support ES5');
}

'use strict';

require('../../libs/jquery.jqplot.min');
require('../../libs/jqplot.cursor.min');
require('../../libs/jqplot.dateAxisRenderer.min');
require('../../libs/jqplot.enhancedLegendRenderer.min');
require('../../libs/jqplot.highlighter.min');

var RatesAside = require('../compiled/ratesAside');
var RatesCurrent = require('../compiled/ratesCurrent');
var RatesTabs = require('../compiled/ratesTabs');
var RatesDetails = require('../compiled/ratesDetails');
var RatesTableView = require('../compiled/ratesTableView');

var RatesWidget = React.createClass({
    getDefaultProps: function() {
        return {};
    },
    DOM: {},
    urls: require('./../../urls.js'),
    tabs: [],
    hideTableView: function() {
        this.setState({
            tableView: null
        });
    },
    showTableView: function(code) {
        this.setState({
            tableView: code
        });
    },
    componentWillMount: function() {
        this.utils = this.utils();
    },
    changePeriod: function(newPeriod) {
        var fromDate;
        var dateFormat = this.props.dateFormat;
        var today = moment();

        if (newPeriod === 'custom') {

        } else {
            if (newPeriod === 'month') {
                fromDate = moment().subtract(1, 'month').format(dateFormat);
            } else if (newPeriod === 'halfyear') {
                fromDate = moment().subtract(6, 'month').format(dateFormat);
            } else if (newPeriod === 'quarter') {
                fromDate = moment().subtract(1, 'quarter').format(dateFormat);
            } else if (newPeriod === 'year') {
                fromDate = moment().subtract(1, 'year').format(dateFormat);
            } else {
                this.utils.log('error', 'Rates: unknown period literal');
            }

            this.setState({
                fromDate: fromDate,
                toDate: today.format(dateFormat)
            });
        }

        this.setState({
            period: newPeriod
        });
    },
    changeDate: function(e) {
        var prop = e.target.getAttribute('data-property');
        var newStateProp = {};
        newStateProp[prop] = e.target.value;

        this.setState(newStateProp);
    },
    onDatedLoaded: function() {
        this.drawPlot();
    },
    onRangesLoaded: function() {
        this.requestDated();
    },
    initDatepicker: function(el) {
        var self = this;
        if (!el) {
            return;
        }
        el = el.getDOMNode();
        self.DOM[el.name] = el;

        $(el).datepicker({
            changeYear: true,
            yearRange: "2000:2100",
            minDate: moment(this.props.dict.dataAvailabilityDate, this.props.dateFormat).toDate(),
            maxDate: new Date,
            beforeShow: function(input, datepicker) {
                if (input.getAttribute('data-property') === 'toDate') {
                    $(input)
                        .datepicker('option', 'minDate', moment(self.state.fromDate, self.props.dateFormat).toDate())
                        .datepicker('option', 'maxDate', new Date);
                } else if (input.getAttribute('data-property') === 'fromDate') {
                    $(input)
                        .datepicker('option', 'maxDate', moment(self.state.toDate, self.props.dateFormat).toDate())
                        .datepicker('option', 'minDate', moment(self.props.dict.dataAvailabilityDate, self.props.dateFormat).toDate());
                }
            },
            onSelect: function(date) {
                var newState = {
                    period: 'custom'
                };

                newState[el.getAttribute('data-property')] = date;
                console.warn(newState)
                self.setState(newState);
            }
        });
    },
    componentDidMount: function() {
        $(document.body).on('click', '.filter-datepicker-trigger', function() {
            $(this).prev('input').focus();
        });

        if (this.props.mode === 'metal') {
            this.tabs = ['history'];
        } else {
            this.tabs = ['history', 'table'];
        }

        if (this.state.period === 'custom') {
            this.setState({
                fromDate: moment().subtract(1, 'week').format(this.props.dateFormat),
                toDate: moment().format(this.props.dateFormat)
            });
        }
        this.changePeriod(this.state.period);

        this.actions = require('../../ratesActions').call(this);

        this.actions.requestInfo();
        this.actions.requestCurrent(true);
        this.requestDetails();
    },
    drawPlot: function(code) {
        this.actions.drawPlot(code ? [].concat(code) : this.utils.getCodes('checked'));
    },
    requestConversion: function() {
        this.actions.requestConversion();
    },
    requestDated: function() {
        // as soon as new ranges arrive this will be called
        // don't call this method directly! ranges must be called first
        this.actions.requestDated();
    },
    requestRanges: function() {
        this.actions.requestRanges();
    },
    requestCurrent: function() {
        this.actions.requestCurrent();
    },
    requestDetails: function() {
        var viewMode = this.state.viewMode;
        if (viewMode === 'history') {
            this.requestRanges();
        } else if (viewMode === 'table') {
            this.requestCurrent();
        }
    },
    print: function(id) {
        var self = this;
        var newState = {};

        self.setState(_.assign(newState, {
            printSection: id
        }), function() {
            $('#plot-' + id).find('.jqplot-table-legend-swatch-outline div').each(function() {
                var width = this.clientWidth;
                var height = this.clientHeight;
                var fill = this.style.backgroundColor;
                $(this)
                    .hide()
                    .after('<svg width="' + width + '" height="' + height + '"><rect width="' + width + '" height="' + height + '" fill="' + fill + '"/></svg>');
            });

            $(document.body).addClass('print-rates');
            window.print();
            $(document.body).removeClass('print-rates');
            self.setState({
                printSection: null
            });
        });
    },
    getInitialState: function() {
        var props = this.props;

        return {
            error: {
                info: false
            },
            loaded: {
                converterResult: false,
                current: false,
                dated: false,
                detailed: false,
                ranges: false
            },
            cachedParams: {
                converter: {},
                dated: {},
                datedBody: {},
                detailed: {},
                ranges: {}
            },
            converterAmount: props.converterAmount,
            converterDate: moment().format(props.dateFormat),
            converterDateSelect: 'current',
            converterFrom: props.sourceCurrencyCode,
            converterResult: null,
            converterTo: props.destCurrencyCode,
            data: $.extend(true, {}, props.codes),
            detailedDate: moment().format(props.dateFormat),
            fromDate: null,
            period: props.period,
            ratesCurrentLatestChange: 0,
            toDate: null,
            viewMode: props.viewMode,
            sourceCode: '',
            destinationCode: '',
            exchangeType: '',
            servicePack: ''
        };
    },
    render: function() {
        var widgetContent;

        if (this.state.error.info) {
            widgetContent = (
                <div>{this.props.dict.loadingError}</div>
            )
        } else {
            if (this.utils.getCodes('name').length) {
                widgetContent = [
                    <RatesCurrent Rates={this} ref="Current" key="0"/>,
                    <RatesAside Rates={this} ref="Aside" key="1"/>,
                    <RatesTabs Rates={this} ref="Tabs" key="2"/>,
                    <RatesDetails Rates={this} ref="Details" key="3"/>,
                    this.state.tableView && <RatesTableView Rates={this} ref="Modal" key="4"/>
                ];
            } else {
                widgetContent = <div>{this.props.dict.loading}</div>;
            }
        }

        return (
            <div className="widget-rates">
                {widgetContent}
            </div>
        )
    },
    utils: function() {
        var self = this;

        return {
            getRangesDescription: function(ranges) {
                return Object.keys(ranges).map(function(el) {
                    return ranges[el].amountFrom;
                }).sort(function(a, b) {
                    return a - b;
                }).map(function(el, i, arr) {
                    var nextMax = el;
                    for (var j = i; j < arr.length; j++) {
                        if (arr[j] > el) {
                            nextMax = arr[j];
                            break;
                        }
                    }
                    if (nextMax === el) {
                        return self.props.dict.detailsRangeFrom + ' ' + el;
                    } else {
                        return el + '-' + nextMax;
                    }
                });
            },
            getCheckedRange: function(code) {
                if (self.state.data[code].ranges) {
                    return self.state.data[code].ranges.filter(function(range) {
                        return range.checked;
                    })[0].amountFrom;
                }
            },
            getCodes: function(property, inverse, dontSort) {
                var codes = Object.keys(self.state.data).filter(function(code) {
                    return inverse ? !self.state.data[code][property] : self.state.data[code][property];
                });

                if (!dontSort) {
                    codes = codes.sort(function(a, b) {
                        // if a code has an 'order' number, prioritize it and sort by number
                        // else sort it alphabetically
                        a = self.state.data[a];
                        b = self.state.data[b];

                        return (a.order || a.name.charCodeAt()) - (b.order || b.name.charCodeAt());
                    });
                }

                return codes;
            },
            capitalize: function(str) {
                return str.replace(/\w/, function(m) {
                    return m.toUpperCase()
                });
            },
            log: function() {
                var args = Array.prototype.slice.call(arguments);
                var firstArg = args[0];
                if (firstArg === 'warn' || firstArg === 'error' || firstArg === 'debug') {
                    args.shift();
                } else {
                    firstArg = 'log';
                }

                if (typeof args[0] === 'string') {
                    // for string interpolation to work
                    args[0] = 'Rates: ' + args[0];
                } else {
                    args = ['Rates:'].concat(args);
                }
                console[firstArg].apply(console, args);
            }
        }
    },
    plugins: {
        select: require('../../libs/SBR.plugin.Select'),
        popup: require('../../libs/SBR.plugin.Popup')
    }
});

module.exports = RatesWidget;