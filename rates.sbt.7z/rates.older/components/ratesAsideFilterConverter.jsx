'use strict';

var AsideFilterConverter = React.createClass({
    componentDidUpdate: function() {
        var Rates = this.props.Rates;
        var Aside = this.props.Aside;

        Rates.DOM.converterAmount = this.refs.converterAmount.getDOMNode();
        Aside.initSelect(this.refs.converterFrom.getDOMNode());
        Aside.initSelect(this.refs.converterTo.getDOMNode());
    },
    render: function() {
        var Rates = this.props.Rates;
        var Aside = this.props.Aside;
        var HoverNote = require('./../../../../components/compiled/hoverNotePositioned');

        var premiumServiceNote;

        // if there is a currency selected which is not in a premiumServiceAllowedCodes array and is not '' (RUR) for first/premium service types, show a warning
        if (Rates.state.servicePack !== 'empty') {
            var wrongCodes = [];

            if (Rates.state.converterFrom && !~Rates.props.premiumServiceAllowedCodes.indexOf(Rates.state.converterFrom)) {
                wrongCodes.push(Rates.state.data[Rates.state.converterFrom].isoName);
            }
            if (Rates.state.converterTo && !~Rates.props.premiumServiceAllowedCodes.indexOf(Rates.state.converterTo)) {
                wrongCodes.push(Rates.state.data[Rates.state.converterTo].isoName);
            }

            if (wrongCodes.length) {
                premiumServiceNote = <span className="rates-aside-error">{Rates.props.dict.converterOptionsError + ': ' + wrongCodes.join(', ')}</span>;
            }
        }


        return (
            <div className="rates-aside-filter rates-container">
                <div className="filter-block">
                    <div>
                        <h6>{Rates.props.dict.filterConverter}</h6>
                    </div>
                    <div className="filter-block-line">
                        <div className="filter-block-line-right input">
                            <form onSubmit={Aside.updateConverter}>
                                <input
                                    maxLength="12"
                                    placeholder={Rates.props.dict.filterConverterAmount}
                                    value={Rates.state.converterAmount}
                                    onInput={Aside.changeAmount}
                                    onChange={$.noop}
                                    ref="converterAmount"
                                    />
                            </form>
                        </div>
                    </div>
                    <div className="filter-block-line">
                        <div className="filter-block-line-left">
                            <span>{Rates.props.dict.filterConverterFrom}</span>
                        </div>
                        <div className="filter-block-line-right">
                            <select
                                ref="converterFrom"
                                value={Rates.state.converterFrom}
                                name="converterFrom"
                                onChange={Aside.selectCode}>
                                <option key={0} value={''}>{Rates.props.destinationCurrency}</option>
                                {Object.keys(Rates.state.data).map(function(code, i) {
                                    return (
                                        <option key={i + 1} value={code}>{Rates.state.data[code].isoName}</option>
                                    )
                                })}
                            </select>
                        </div>
                    </div>
                    <div className="filter-block-line">
                        <div className="filter-block-line-left">
                            <span>{Rates.props.dict.filterConverterTo}</span>
                        </div>
                        <div className="filter-block-line-right">
                            <select
                                ref="converterTo"
                                value={Rates.state.converterTo}
                                name="converterTo"
                                onChange={Aside.selectCode}>
                                <option key={0} value={''}>{Rates.props.destinationCurrency}</option>
                                {Object.keys(Rates.state.data).map(function(code, i) {
                                    return (
                                        <option key={i + 1} value={code}>{Rates.state.data[code].isoName}</option>
                                    )
                                })}
                            </select>
                        </div>
                    </div>
                </div>
                <div className="filter-block">
                    <div>
                        <h6>{Rates.props.dict.filterConverterSource}</h6>
                        <HoverNote text={Rates.props.dict.filterConverterSourceTip}/>
                    </div>
                    {['card', 'account', 'cash'].map(function(el, i) {
                        return (
                            <label key={i}>
                                <input
                                    type="radio"
                                    name="sourceCode"
                                    checked={Rates.state.sourceCode === el ? true : false}
                                    value={el}
                                    onChange={Aside.changeConverterOpts}/>
                                <span className="radio"/>
                                <p>
                                    {Rates.props.dict['filterConverterSource' + Rates.utils.capitalize(el)]}
                                </p>
                            </label>
                        )
                    })}
                </div>
                <div className="filter-block">
                    <div>
                        <h6>{Rates.props.dict.filterConverterDest}</h6>
                        <HoverNote text={Rates.props.dict.filterConverterDestTip}/>
                    </div>
                    {['card', 'account', 'cash'].map(function(el, i) {
                        return (
                            <label key={i}>
                                <input
                                    type="radio"
                                    name="destinationCode"
                                    checked={Rates.state.destinationCode === el ? true : false}
                                    value={el}
                                    onChange={Aside.changeConverterOpts}/>
                                <span className="radio"/>
                                <p>
                                    {Rates.props.dict['filterConverterDest' + Rates.utils.capitalize(el)]}
                                </p>
                            </label>
                        )
                    })}
                </div>
                <div className="filter-block">
                    <div>
                        <h6>{Rates.props.dict.filterConverterExchange}</h6>
                        <HoverNote text={Rates.props.dict.filterConverterExchangeTip}/>
                    </div>
                    {['ibank', 'office', 'atm'].map(function(el, i) {
                        return (
                            <label key={i}>
                                <input
                                    type="radio"
                                    name="exchangeType"
                                    checked={Rates.state.exchangeType === el ? true : false}
                                    value={el}
                                    onChange={Aside.changeConverterOpts}/>
                                <span className="radio"/>
                                <p>
                                    {Rates.props.dict['filterConverterExchange' + Rates.utils.capitalize(el)]}
                                </p>
                            </label>
                        )
                    })}
                </div>
                <div className="filter-block">
                    <div>
                        <h6>{Rates.props.dict.filterConverterService}</h6>
                        <HoverNote text={Rates.props.dict.filterConverterServiceTip}/>
                    </div>
                    {['empty', 'premier', 'first'].map(function(el, i) {
                        return (
                            <label key={i}>
                                <input
                                    type="radio"
                                    name="servicePack"
                                    checked={Rates.state.servicePack === el ? true : false}
                                    value={el}
                                    onChange={Aside.changeConverterOpts}/>
                                <span className="radio"/>
                                <p>
                                    {Rates.props.dict['filterConverterService' + Rates.utils.capitalize(el)]}
                                </p>
                            </label>
                        )
                    })}
                    {premiumServiceNote}
                </div>
                <div className="filter-block">
                    <div>
                        <h6>{Rates.props.dict.filterConverterDate}</h6>
                        <HoverNote text={Rates.props.dict.filterConverterDateTip}/>
                    </div>
                    {['current', 'select'].map(function(el, i) {
                        return (
                            <label key={i}>
                                <input
                                    type="radio"
                                    name="converterDateSelect"
                                    checked={Rates.state.converterDateSelect === el ? true : false}
                                    value={el}
                                    onChange={Aside.changeConverterOpts}/>
                                <span className="radio"/>
                                <p>
                                    {Rates.props.dict['filterConverterDate' + Rates.utils.capitalize(el)]}
                                </p>
                            </label>
                        )
                    })}
                </div>
                <div className="filter-block">
                    <button className="button" onClick={Aside.updateConverter}>{Rates.props.dict.show}</button>
                </div>
            </div>
        )
    }
});

module.exports = AsideFilterConverter;