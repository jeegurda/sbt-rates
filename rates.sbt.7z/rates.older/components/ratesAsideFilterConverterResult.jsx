'use strict';

var AsideFilterConverterResult = React.createClass({
    shouldComponentUpdate: function(state) {
        var Rates = this.props.Rates;

        if (Rates.state.loaded.converterResult) {
            Rates.setState({
                loaded: _.assign({}, Rates.state.loaded, {
                    converterResult: false
                })
            });
            return true;
        } else {
            return false;
        }
    },
    componentDidMount: function() {
        var Rates = this.props.Rates;

        if (this.refs.converterResult) {
            Rates.DOM.converterResult = this.refs.converterResult.getDOMNode();
        }
    },
    componentDidUpdate: function() {
        var result = this.props.Rates.DOM.converterResult;
        var resultBottom = result.getBoundingClientRect().bottom;
        var diff = resultBottom - window.innerHeight;

        if (diff > 0) {
            $('html, body').animate({
                scrollTop: $(window).scrollTop() + diff
            }, 200);
        }
    },
    render: function() {
        var Aside = this.props.Aside;
        var Rates = this.props.Rates;

        if ($.isNumeric(Rates.state.converterResult)) {
            return (
                <div className="converter-result" ref={function(el) {
                    Rates.DOM.converterResult = el;
                }}>
                    <h3>{Rates.props.dict.filterConverterResult}</h3>
                    <h5>
                        {Rates.state.converterAmount}
                        {Rates.state.converterFrom ? Rates.state.data[Rates.state.converterFrom].isoName : Rates.props.destinationCurrency}
                        =
                    </h5>
                    <h4>
                        {Rates.state.converterResult}
                        {Rates.state.converterTo ? Rates.state.data[Rates.state.converterTo].isoName : Rates.props.destinationCurrency}
                    </h4>
                </div>
            )
        } else {
            return null;
        }
    }
});

module.exports = AsideFilterConverterResult;