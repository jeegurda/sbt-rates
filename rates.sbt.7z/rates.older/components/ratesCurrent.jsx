'use strict';

var RatesCurrent = React.createClass({
    shouldComponentUpdate: function() {
        var Rates = this.props.Rates;

        if (Rates.state.loaded.current) {
            /*Rates.setState({
                loaded: _.assign({}, Rates.state.loaded, {
                    current: false
                })
            });*/
            Rates.state.loaded.current = false;
            return true;
        } else {
            return false;
        }
    },
    render: function() {
        var self = this;
        var Rates = this.props.Rates;
        var note;
        var mode = Rates.props.mode;
        var ratesType = Rates.props.ratesType;

        if (ratesType === 'first' || ratesType === 'premium') {

            var noteText = Rates.props.dict['currentNoteFragment' + (Rates.props.mode === 'metal' ? 'Metal' : 'Currency')];
            var noteLinkUrl = Rates.props.dict[ratesType + 'Link' + Rates.utils.capitalize(Rates.props.language)];
            var noteLinkText = Rates.props.dict.currentNoteFragmentLink.format(Rates.props.dict['currentNote' + Rates.utils.capitalize(ratesType)]);

            var noteLink = '<a href="{0}" target="_blank">{1}</a>'.format(noteLinkUrl, noteLinkText);

            note = (
                <div className="current-rates-note rates-note">
                    <strong>{Rates.props.dict.currentNoteBold}</strong>
                    <span> </span>
                    <span dangerouslySetInnerHTML={{
                        __html: noteText.format(noteLink)
                    }}></span>
                </div>
            )
        }

        if (Rates.utils.getCodes('checked').some(function(el) {
            return Rates.state.data[el].ratesCurrent;
        })) {
            return (
                <div className="rates-current rates-right">
                    <div className="current-rates rates-container">
                        <div className="current-table">
                            <table>
                                <thead>
                                    <tr>
                                        <th>{Rates.props.dict['current' + (Rates.props.mode === 'metal' ? 'Metal' : 'Currency')]}</th>
                                        <th>{Rates.props.dict.currentBuy}</th>
                                        <th>{Rates.props.dict.currentSell}</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {Rates.utils.getCodes('checked').map(function(el, i) {
                                        var item = Rates.state.data[el];
                                        var itemRates = item.ratesCurrent;

                                        // if for some reason checked element wasn't loaded yet (few requests on a slow connection)
                                        if (itemRates) {
                                            var buyClassName = itemRates.buyChange > 0 ?
                                                'rates-up'
                                                :
                                                (itemRates.buyChange < 0 ?
                                                    'rates-down'
                                                    :
                                                    'rates-none');
                                            var sellClassName = itemRates.sellChange > 0 ?
                                                'rates-up'
                                                :
                                                (itemRates.sellChange < 0 ?
                                                    'rates-down'
                                                    :
                                                    'rates-none');
                                            var itemTitle;

                                            if (Rates.props.mode === 'metal') {
                                                itemTitle = item.name;
                                            } else {
                                                itemTitle = [
                                                    item.isoName,
                                                    <em key={1}> / {Rates.props.destinationCurrency}</em>
                                                ]
                                            }

                                            var buyTitle = itemRates.buyChange > 0 ?
                                                (Rates.props.dict.currentIncrease + ': ' + itemRates.buyChange.toFixed(2))
                                                :
                                                (itemRates.buyChange < 0 ?
                                                    (Rates.props.dict.currentDecrease + ': ' + itemRates.buyChange.toFixed(2))
                                                    :
                                                    null);
                                            var sellTitle = itemRates.sellChange > 0 ?
                                                (Rates.props.dict.currentIncrease + ': ' + itemRates.sellChange.toFixed(2))
                                                :
                                                (itemRates.sellChange < 0 ?
                                                    (Rates.props.dict.currentDecrease + ': ' + itemRates.sellChange.toFixed(2))
                                                    :
                                                    null);

                                            return (
                                                <tr key={i}>
                                                    <td>{itemTitle}</td>
                                                    <td title={buyTitle}>
                                                        <span className={buyClassName}>
                                                            {typeof itemRates.buyValue === 'number' ? itemRates.buyValue.toFixed(2) : '-'}
                                                        </span>
                                                    </td>
                                                    <td title={sellTitle}>
                                                        <span className={sellClassName}>
                                                            {typeof itemRates.sellValue === 'number' ? itemRates.sellValue.toFixed(2) : '-'}</span>
                                                    </td>
                                                </tr>
                                            )
                                        }
                                    })}
                                </tbody>
                            </table>
                        </div>
                        <div className="current-info">
                            {Rates.props.dict.currentInfo.format(
                                moment(Rates.state.ratesCurrentLatestChange).format(Rates.props.dateFormat + ' h:mm')
                            )}
                        </div>
                    </div>
                    {note}
                </div>
            )
        } else {
            return null;
        }
    }
});

module.exports = RatesCurrent;