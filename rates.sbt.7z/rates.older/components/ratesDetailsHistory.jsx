'use strict';

var DetailsHistory = React.createClass({
    renderDetails: function(item, code) {
        var Rates = this.props.Rates;
        var Details = this.props.Details;
        var rangeSelect;

        // if data for code is missing (no ranges) or plot wasn't built (no data, empty values array, jqplot errors)
        if (item.ratesDated === 'NODATA' || item.plot === null) {
            return [
                <div key="0">{Rates.props.dict.noData}</div>,
                <div id={'plot-' + code} className="details-item-plot plot-no-data" key="1"></div>
            ]
        } else {
            // ranges should be there, but if it's the only one, don't display it
            if (item.ranges.length > 1) {
                rangeSelect = (
                    <div className="rl-right">
                        <span onClick={Details.toggleRangePopup.bind(null, true, code)}>
                            {Rates.props.dict.detailsSelectRange}
                        </span>
                        <div className={'rates-container rl-range' + (item.rangePopupVisible ? ' visible' : '')}>
                            <p>{Rates.props.dict.detailsSelectRange}</p>
                            <p>
                                {Rates.utils.getRangesDescription(item.ranges).map(function(el, j) {
                                    return (
                                        <span
                                            onClick={Details.changeRange.bind(null, code)}
                                            data-range-from={item.ranges[j].amountFrom}
                                            className={item.ranges[j].checked ? 'checked' : ''}
                                            key={j}>
                                            {el}
                                        </span>
                                    )
                                })}
                            </p>
                        </div>
                    </div>
                )
            }

            return [
                <div className="rates-links" key="0">
                    <div className="rl-left">
                        <span className="rl-print" onClick={Rates.print.bind(null, code)}>{Rates.props.dict.print}</span>
                        <span onClick={Rates.showTableView.bind(null, code)}>{Rates.props.dict.tableView}</span>
                    </div>
                    {rangeSelect}
                </div>,
                <div id={'plot-' + code} className="details-item-plot" key="1"></div>
            ]
        }
    },
    componentDidUpdate: function() {
        var Rates = this.props.Rates;

        Rates.initDatepicker(this.refs.filterDatepickerDetailsFrom);
        Rates.initDatepicker(this.refs.filterDatepickerDetailsTo);
    },
    render: function() {
        var Rates = this.props.Rates;
        var Details = this.props.Details;
        var converterPeriod;
        var self = this;

        if (Rates.props.mode === 'converter') {
            converterPeriod = (
                <div className="rates-details-period">
                    <div className="rates-details-period-title">
                        {Rates.state.data[Rates.state.converterFrom || Rates.state.converterTo].isoName}
                        <em>
                            /
                            {Rates.props.destinationCurrency}
                        </em>
                    </div>
                    <div className="rates-details-period-datepicker">
                        {['from', 'to'].map(function(el, i) {
                            return ([
                                <p>{Rates.props.dict['filter' + Rates.utils.capitalize(el)]}</p>,
                                <div className="filter-datepicker input">
                                    <input
                                        name={'filter-datepicker-details-' + el}
                                        data-property={el + 'Date'}
                                        value={Rates.state[el + 'Date']}
                                        onChange={Details.changeDate}
                                        ref={'filterDatepickerDetails' + Rates.utils.capitalize(el)}
                                    />
                                    <span className="filter-datepicker-trigger"/>
                                </div>
                            ])
                        })}
                        <button className="button" onClick={Details.updateDetails}>{Rates.props.dict.show}</button>
                    </div>
                </div>
            )
        }

        return (
            <div className="rates-details">
                {converterPeriod}
                <div className="rates-details-graphs">
                    {Rates.utils.getCodes('ratesDated').map(function(code) {
                        var item = Rates.state.data[code];

                        // important to use 'code' here as a key, so that div with a graph could be properly removed
                        return (
                            <div className={'details-item' + (Rates.state.printSection === code ? ' print-visible' : '')} key={code}>
                                <h2 className={(Rates.props.mode === 'converter' && !Rates.state.printSection) ? 'collapse' : ''}>{item.name}</h2>
                                <div className="scroll-content">
                                    {self.renderDetails(item, code)}
                                </div>
                            </div>
                        )

                    })}
                </div>
                <div className="rates-details-availability-note">
                    <p>
                        {Rates.props.dict.dataAvailability}
                        <span> </span>
                        {Rates.props.dict.dataAvailabilityDate}
                    </p>
                </div>
            </div>
        )

    }
});

module.exports = DetailsHistory;