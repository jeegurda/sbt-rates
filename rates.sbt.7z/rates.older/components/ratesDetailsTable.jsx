'use strict';

var DetailsTable = React.createClass({
    renderValues: function(item) {
        var itemRates = item.ratesDetailed;
        var buyClassName = itemRates.buyChange > 0 ? 'rates-up' : (itemRates.buyChange < 0 ? 'rates-down' : 'rates-none');
        var sellClassName = itemRates.sellChange > 0 ? 'rates-up' : (itemRates.sellChange < 0 ? 'rates-down' : 'rates-none');

        return [
            <td key="0">
                {typeof itemRates.buyValue === 'number' ?
                    [
                        itemRates.buyValue.toFixed(2) + ' (',
                        <span className={buyClassName} key="0">{itemRates.buyChange.toFixed(2)}</span>,
                        ')'
                    ]
                :
                    '\u2014'
                }
            </td>,
            <td key="1">
                {typeof itemRates.sellValue === 'number' ?
                    [
                        itemRates.sellValue.toFixed(2) + ' (',
                        <span className={sellClassName} key="0">{itemRates.sellChange.toFixed(2)}</span>,
                        ')'
                    ]
                :
                    '\u2014'
                }
            </td>
        ]
    },
    render: function() {
        var Rates = this.props.Rates;
        var self = this;

        return (
            <div className="rates-details">
                {Rates.utils.getCodes('checked').some(function(el) {
                    return Rates.state.data[el].ratesDetailed;
                }) &&
                    <div className="rates-details-table">
                        <table className="details-table">
                            <thead>
                                <tr>
                                    {['detailsName', 'detailsCode', 'detailsAmount', 'detailsBuy', 'detailsSell'].map(function(el, i) {
                                        return (
                                            <th key={i}>{Rates.props.dict[el]}</th>
                                        )
                                    })}
                                </tr>
                            </thead>
                            <tbody>
                                {Rates.utils.getCodes('checked').map(function(code, i) {
                                    var item = Rates.state.data[code];

                                    // if it's checked and has something to show
                                    if (item.ratesDetailed) {
                                        return (
                                            <tr key={i}>
                                                <td>{item.name}</td>
                                                <td>{item.isoName}</td>
                                                <td>{item.scale}</td>
                                                {self.renderValues(item)}
                                            </tr>
                                        )
                                    }
                                })}
                            </tbody>
                        </table>
                    </div>
                }
                <div className="rates-details-note rates-note">
                    <p>{Rates.props.dict.detailsNoteFragment1}</p>
                    <p>{Rates.props.dict.detailsNoteFragment2}</p>
                </div>
            </div>
        )
    }
});

module.exports = DetailsTable;