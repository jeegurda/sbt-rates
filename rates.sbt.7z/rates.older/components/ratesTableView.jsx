'use strict';

var RatesTableView = React.createClass({
    handleModalHide: function() {
        // var Rates = this.props.Rates;

        // Rates.hideTableView();
    },
    componentDidMount: function() {
        // minus overlay margin from both sides, minus table bottom margin
        var spaceLeft = window.innerHeight - 40 * 2 - this.refs.table.getDOMNode().offsetTop - 40;
        this.refs.tableContainer.getDOMNode().style.maxHeight = spaceLeft + 'px';
    },
    render: function() {
        var Rates = this.props.Rates;
        var Modal = ReactBootstrap.Modal;

        var data = Rates.state.data[Rates.state.tableView];
        var lastDate;
        var recordCounter = 0;
        var limitReached = false;

        return (
            <Modal onRequestHide={Rates.hideTableView} keyboard={true} className="rates-table-view">
                <div className="rates-table-view-close" onClick={Rates.hideTableView}>
                    <span>{Rates.props.dict.tableViewClose}</span>
                </div>
                <h2>{Rates.props.dict.tableView + ', ' + data.isoName}</h2>
                <a className="rates-table-view-download" href={SBT.TOOLBOX.tools.concatPipedURL(Rates.urls.xls, {
                        currencyCode: Rates.state.tableView,
                        fromDate: Rates.state.fromDate,
                        toDate: Rates.state.toDate,
                        regionId: Rates.props.regionId,
                        categoryCode: Rates.props.ratesType,
                        rangesAmountFrom: data.ranges.map(function(el) {
                            return el.amountFrom;
                        })
                    })}>
                    {Rates.props.dict.tableViewDownload}
                </a>
                <div ref="tableContainer" className="table-container">
                    <table ref="table">
                        <thead>
                            <tr>
                                {[
                                    Rates.props.dict.tableViewDate,
                                    Rates.props.dict.tableViewTime,
                                    Rates.props.dict.tableViewAmount,
                                    Rates.props.dict.tableViewFrom,
                                    Rates.props.dict.tableViewTo,
                                    Rates.props.dict.tableViewBuy,
                                    Rates.props.dict.tableViewSell
                                ].map(function(el, i) {
                                    return <th key={i}>{el}</th>;
                                })}
                            </tr>
                        </thead>
                        <tbody>
                            {data.ratesDated.map(function(el, i) {
                                var newRecord = el.activeFrom !== lastDate;
                                lastDate = el.activeFrom;

                                if (limitReached || (newRecord && ++recordCounter > 200)) {
                                    limitReached = true;
                                    return;
                                }

                                return (
                                    <tr className={newRecord ? 'rates-record' : null} key={i}>
                                        <td>{newRecord ? moment(lastDate).format(Rates.props.dateFormat) : null}</td>
                                        <td>{newRecord ? moment(lastDate).format(Rates.props.timeFormat) : null}</td>
                                        <td>{newRecord ? data.scale : null}</td>
                                        <td>{$.isNumeric(el.rangeFrom) ? el.rangeFrom : '\u2014'}</td>
                                        <td>{$.isNumeric(el.rangeTo) ? el.rangeTo : '\u2014'}</td>
                                        <td>{typeof el.buyValue === 'number' ? el.buyValue.toFixed(2) : '\u2014'}</td>
                                        <td>{typeof el.sellValue === 'number' ? el.sellValue.toFixed(2) : '\u2014'}</td>
                                    </tr>
                                )
                            })}
                        </tbody>
                    </table>
                </div>
            </Modal>
        )
    }
});

module.exports = RatesTableView;