/**
 * You can also use following 4 parameters for 'requestDated' and 'requestRanges' methods
 * 'categoryCode' property is used as a shortcut, making them all insignificant
 *
 * For example
 *
 * sourceCode: Rates.state.sourceCode,
 * destinationCode: Rates.state.destinationCode,
 * exchangeType: Rates.state.exchangeType,
 * servicePack: Rates.state.servicePack
 *
 */

module.exports = function(param) {
    var Rates = this;
    var tools = SBT.TOOLBOX.tools;

    return {
        requestInfo: function() {
            var nameProp = 'currencyName' + (Rates.props.language === 'en' ? 'Eng' : '');
            var params = {
                type: Rates.props.mode === 'metal' ? 'METAL' : 'CURRENCY'
            };

            $.ajax({
                url: tools.concatPipedURL(Rates.urls.info, params),
                error: function(xhr) {
                    Rates.setState({
                        error: _.assign({}, Rates.state.error, {
                            info: true
                        })
                    })
                    Rates.utils.log('warn', 'ajax error. %d: %s', xhr.status, xhr.responseJSON ? (xhr.responseJSON.message || 'Empty message') : (xhr.responseText || 'No text. Check URL or connection'));
                },
                success: function(response) {
                    var newStateData = _.assign({}, Rates.state.data);

                    if (!response.length) {
                        Rates.utils.log('warn', 'empty array received for currency type ', params.type);
                    } else {
                        response.forEach(function(el) {
                            // no conflict with data setting requests
                            !newStateData[el.currencyCode] && (newStateData[el.currencyCode] = {});

                            if (Rates.props.codes[el.currencyCode]) {
                                newStateData[el.currencyCode].display = true;
                                newStateData[el.currencyCode].checked = Rates.props.codes[el.currencyCode].checked;
                            } else {
                                newStateData[el.currencyCode].display = false;
                                newStateData[el.currencyCode].checked = false;
                            }

                            newStateData[el.currencyCode].name = el[nameProp];
                            newStateData[el.currencyCode].isoName = el.isoCur;
                            newStateData[el.currencyCode].order = Rates.props.order[el.currencyCode] || null;
                        });
                    }

                    Rates.setState({
                        data: newStateData
                    });
                },
                complete: function() {
                }
            });
        },
        requestCurrent: function(noDate) {
            var requestCodes = Rates.utils.getCodes('checked', undefined, true);

            var params = {
                regionId: Rates.props.regionId,
                rateCategory: Rates.props.ratesType,
                currencyCode: requestCodes,
                date: noDate ? undefined : (Rates.state.detailedDate + ' 00:00:00')
            };

            if (!noDate && _.isEqual(Rates.state.cachedParams.detailed, params)) {
                return;
            }

            $.ajax({
                url: tools.concatPipedURL(Rates.urls.current, params),
                error: function(xhr) {
                    Rates.utils.log('warn', 'ajax error. %d: %s', xhr.status, xhr.responseJSON ? (xhr.responseJSON.message || 'Empty message') : (xhr.responseText || 'No text. Check URL or connection'));
                },
                success: function(response) {
                    var latestChange = 0;

                    var newStateData = _.assign({}, Rates.state.data);

                    requestCodes.forEach(function(code) {
                        var item = response[Rates.props.ratesType][code];

                        // no conflict with data setting requests
                        !newStateData[code] && (newStateData[code] = {});

                        if (item) {
                            newStateData[code][noDate ? 'ratesCurrent' : 'ratesDetailed'] = {
                                buyValue: item.buyValue,
                                sellValue: item.sellValue,
                                buyChange: item.buyValue - item.buyValuePrev,
                                sellChange: item.sellValue - item.sellValuePrev
                            };
                            newStateData[code].scale = item.scale;

                            if (noDate && item.activeFrom > latestChange) {
                                latestChange = item.activeFrom;
                            }
                        } else {
                            newStateData[code][noDate ? 'ratesCurrent' : 'ratesDetailed'] = {
                                buyValue: '\u2014',
                                sellValue: '\u2014',
                                buyChange: 0,
                                sellChange: 0
                            };
                            newStateData[code].scale = '\u2014';
                            Rates.utils.log('warn', 'no current rates for code %s received', code);
                        }
                    });

                    if (noDate) {
                        Rates.setState({
                            ratesCurrentLatestChange: latestChange
                        });
                    } else {
                        Rates.setState({
                            cachedParams: _.assign({}, Rates.state.cachedParams, {
                                detailed: params
                            })
                        });
                    }
                    Rates.setState({
                        loaded: _.assign({}, Rates.state.loaded, {
                            current: true
                        }),
                        data: newStateData
                    });
                },
                complete: function() {
                }
            });
        },
        requestRanges: function() {
            var requestCodes = Rates.utils.getCodes('checked', undefined, true);
            var params = {
                regionId: Rates.props.regionId,
                currencyCode: requestCodes,
                categoryCode: Rates.props.ratesType
            };

            if (_.isEqual(Rates.state.cachedParams.ranges, params)) {
                Rates.setState({
                    loaded: _.assign({}, Rates.state.loaded, {
                        ranges: true
                    })
                });
                Rates.onRangesLoaded();
                return;
            }

            $.ajax({
                url: tools.concatPipedURL(Rates.urls.ranges, params),
                error: function(xhr) {
                    Rates.utils.log('warn', 'ajax error. %d: %s', xhr.status, xhr.responseJSON ? (xhr.responseJSON.message || 'Empty message') : (xhr.responseText || 'No text. Check URL or connection'));
                },
                success: function(response) {
                    var newStateData = _.assign({}, Rates.state.data);

                    requestCodes.forEach(function(code) {
                        var item = response[code];

                        // no conflict with data setting requests
                        !newStateData[code] && (newStateData[code] = {});

                        if (item) {
                            if (item.length > 0) {
                                item.forEach(function(el, i) {
                                    el.checked = i === 0;
                                });
                                newStateData[code].ranges = item;
                            } else {
                                Rates.utils.log('warn', 'empty ranges array received for code: %s.', code);
                            }
                        } else {
                            Rates.utils.log('warn', 'no ranges received for code: %s.', code);
                        }
                        newStateData[code].rangePopupVisible = false;
                    });

                    Rates.setState({
                        data: newStateData,
                        cachedParams: _.assign({}, Rates.state.cachedParams, {
                            ranges: params
                        }),
                        loaded: _.assign({}, Rates.state.loaded, {
                            ranges: true
                        })
                    });
                    Rates.onRangesLoaded();
                },
                complete: function() {
                }
            });
        },
        requestDated: function() {
            var postBody = {
                currencyData: [],
                categoryCode: Rates.props.ratesType
            };

            Rates.utils.getCodes('checked', undefined, true).forEach(function(code) {
                // if a code doesn't have a range, skip it
                if (!Rates.state.data[code].ranges) {
                    var newStateData = _.assign({}, Rates.state.data);
                    newStateData[code].ratesDated = 'NODATA';

                    Rates.setState({
                        data: newStateData
                    });
                    return;
                }
                postBody.currencyData.push({
                    currencyCode: code,
                    rangesAmountFrom: Rates.state.data[code].ranges.map(function(el) {
                        return el.amountFrom;
                    }).sort(function(a, b) {
                        return a - b;
                    })
                });
            });

            if (!postBody.currencyData.length) {
                Rates.utils.log('warn', 'No correct ranges to request dated info');

                // removing dated rates for every code exept checked ones
                Rates.utils.getCodes('ratesDated', undefined, true).forEach(function(code) {
                    if (!Rates.state.data[code].checked) {
                        var newStateData = _.assign({}, Rates.state.data);
                        newStateData[code].ratesDated = null;

                        Rates.setState({
                            data: newStateData
                        });
                    }
                });
                return;
            }

            var params = {
                regionId: Rates.props.regionId,
                fromDate: Rates.state.fromDate,
                toDate: Rates.state.toDate
            };

            if (_.isEqual(Rates.state.cachedParams.dated, params) && _.isEqual(Rates.state.cachedParams.datedBody, postBody)) {
                // to redraw plots in cases without ajax (e.g. after a tab change)
                Rates.setState({
                    loaded: _.assign({}, Rates.state.loaded, {
                        dated: true
                    })
                });
                Rates.onDatedLoaded();
                return;
            }

            $.ajax({
                type: 'POST',
                nohash: true,
                data: JSON.stringify(postBody),
                contentType: 'application/json',
                url: tools.concatPipedURL(Rates.urls.rates, params),
                error: function(xhr) {
                    Rates.utils.log('warn', 'ajax error. %d: %s', xhr.status, xhr.responseJSON ? (xhr.responseJSON.message || 'Empty message') : (xhr.responseText || 'No text. Check URL or connection'));
                },
                success: function(response) {
                    var newStateData = _.assign({}, Rates.state.data);

                    // no conflicts should happen here, this request shouldn't be initial

                    Object.keys(Rates.state.data).forEach(function(code) {
                        if (response[code]) {
                            if (response[code].rates) {
                                newStateData[code].ratesDated = response[code].rates;
                            } else {
                                if (!newStateData[code].checked) {
                                    newStateData[code].ratesDated = null;
                                }
                                Rates.utils.log('warn', 'No dated rates received for code: %s.', code);
                            }
                        } else {
                            // same check as before sending ajax, if it's checked, don't remove it
                            if (!newStateData[code].checked) {
                                newStateData[code].ratesDated = null;
                            }
                        }
                    });

                    Rates.setState({
                        data: newStateData,
                        cachedParams: _.assign({}, Rates.state.cachedParams, {
                            dated: params,
                            datedBody: postBody
                        }),
                        loaded: _.assign({}, Rates.state.loaded, {
                            dated: true
                        })
                    });
                    Rates.onDatedLoaded();
                },
                complete: function() {
                }
            });
        },
        requestConversion: function() {
            var params = {
                regionId: Rates.props.regionId,
                sourceCode: Rates.state.sourceCode,
                destinationCode: Rates.state.destinationCode,
                exchangeType: Rates.state.exchangeType,
                servicePack: Rates.state.servicePack,
                fromCurrencyCode: Rates.state.converterFrom, // ok if empty
                toCurrencyCode: Rates.state.converterTo, // ok if empty
                amount: Rates.state.converterAmount
            };

            if (_.isEqual(Rates.state.cachedParams.converter, params)) {
                return;
            }

            if (Rates.state.converterDateSelect === 'custom') {
                params.date = Rates.state.converterDate;
            }

            $.ajax({
                url: tools.concatPipedURL(Rates.urls.convert, params),
                error: function(xhr) {
                    Rates.utils.log('warn', 'ajax error. %d: %s', xhr.status, xhr.responseJSON ? (xhr.responseJSON.message || 'Empty message') : (xhr.responseText || 'No text. Check URL or connection'));
                },
                success: function(response) {
                    if ($.isNumeric(response)) {
                        Rates.setState({
                            converterResult: response,
                            cachedParams: _.assign({}, Rates.state.cachedParams, {
                                converter: params
                            }),
                            loaded: _.assign({}, Rates.state.loaded, {
                                converterResult: true
                            })
                        });
                    } else {
                        Rates.utils.log('warn', 'Can\'t parse response:', response);
                    }
                },
                complete: function() {
                }
            });
        },
        drawPlot: function(codes) {

            codes.forEach(function(code) {
                var plot = {
                    values: {
                        max: {
                            buy: Number.MIN_VALUE,
                            sell: Number.MIN_VALUE,
                            period: Number.MIN_VALUE
                        },
                        min: {
                            buy: Number.MAX_VALUE,
                            sell: Number.MAX_VALUE,
                            period: Number.MAX_VALUE
                        },
                        fill: function(prop, value) {
                            value > plot.values.max[prop] && (plot.values.max[prop] = value);
                            value < plot.values.min[prop] && (plot.values.min[prop] = value);
                        },
                        invalid: function() {
                            return Array.prototype.some.call(arguments, function(arg) {
                                if (!$.isNumeric(arg)) {
                                    return true;
                                }
                            });
                        }
                    },
                    getTooltip: function(type) {
                        return '\
                            <div class="plot-tooltip">\
                                <h3>' + Rates.props.dict['current' + Rates.utils.capitalize(type)] + '</h3>\
                                <p>%s: <em>%s</em></p>\
                                <p>'
                                    + Rates.props.dict.plotMax
                                    + ' <em>'
                                    + this.values.max[type].toFixed(2)
                                    + ' '
                                    + Rates.props.destinationCurrencyShort
                                    + '</em>, '
                                    + Rates.props.dict.plotMin
                                    + ' <em>'
                                    + this.values.min[type].toFixed(2)
                                    + ' '
                                    + Rates.props.destinationCurrencyShort
                                    + '</em></p>\
                            </div>';
                    },
                    getPlotData: function() {
                        var checkedRange = Rates.utils.getCheckedRange(code);

                        if (typeof checkedRange === 'undefined') {
                            // if no range available for the current code
                            return null;
                        }

                        var item = Rates.state.data[code];

                        if (!item.ratesDated) {
                            return null;
                        }

                        var buyValues = [];
                        var sellValues = [];
                        var self = this;

                        item.ratesDated.forEach(function(el) {
                            if (el.rangeFrom === checkedRange) {
                                if (self.values.invalid(el.activeFrom, el.buyValue, el.sellValue)) {
                                    Rates.utils.log('warn', 'bad values for plot with code "%s". %d, %d, %d', code, el.activeFrom, el.buyValue, el.sellValue);
                                    return;
                                }
                                self.values.fill('period', el.activeFrom);
                                self.values.fill('buy', el.buyValue);
                                self.values.fill('sell', el.sellValue);

                                buyValues.push(
                                    [el.activeFrom, el.buyValue]
                                );
                                sellValues.push(
                                    [el.activeFrom, el.sellValue]
                                );
                            }
                        });
                        if (buyValues.length && sellValues.length) {
                            [buyValues, sellValues].forEach(function(arr) {
                                if (arr.length === 1) {
                                    arr[1] = arr[0].slice();
                                    // adding some time to be able to build a plot
                                    arr[1][0] += 100;
                                    self.values.max.period = self.values.min.period + 100;
                                }
                            });
                            return [buyValues.reverse(), sellValues.reverse()];
                        } else {
                            Rates.utils.log('warn', 'empty values array for code %s', code);
                            return null;
                        }
                    },
                    data: undefined,
                    init: function() {
                        return $.jqplot('plot-' + code, this.data, {
                            grid: {
                                backgroundColor: 'transparent',
                                borderWidth: 0,
                                shadow: false,
                                shadowColor: 'transparent'
                            },
                            axes: {
                                xaxis: {
                                    borderWidth: 0,
                                    shadow: false,
                                    renderer: $.jqplot.DateAxisRenderer,
                                    rendererOptions: {
                                        drawBaseline: true
                                    },
                                    tickOptions: {
                                        formatString: '%d.%m.%Y'
                                    },
                                    min: this.values.min.period,
                                    max: this.values.max.period,
                                    numberTicks: 6
                                },
                                yaxis: {
                                    borderWidth: 0,
                                    rendererOptions: {
                                        drawBaseline: false
                                    },
                                    tickOptions: {
                                        formatString:'$%.2f',
                                        tickRenderer: $.jqplot.categoryAxisRenderer,
                                        formatter: function(format, value) {
                                            return value.toFixed(2) + ' ' + Rates.props.destinationCurrencyShort;
                                        }
                                    }
                                }
                            },
                            legend: {
                                show: true,
                                placement: 'outsideGrid',
                                location: 's',
                                renderer: $.jqplot.EnhancedLegendRenderer,
                                rendererOptions: {
                                    numberRows: 1
                                }
                            },
                            highlighter: {
                                show: true,
                                showMarker: true,
                                tooltipAxes: 'both',
                                sizeAdjust: 1,
                                lineWidthAdjust: 0.4,
                                tooltipLocation: 'w',
                                tooltipOffset: 15
                            },
                            cursor: {
                                style: 'default',
                                showTooltip: false,
                                show: true,
                                showVerticalLine: true,
                                intersectionThreshold: 100,
                                followMouse: true,
                                zoom: true,
                                constrainZoomTo: 'x',
                                clickReset: true
                            },
                            seriesDefaults: {
                                shadow: false,
                                lineWidth: 2,
                                markerOptions: {
                                    show: false,
                                    style: 'filledCircle',
                                    lineWidth: 3,
                                    size: 11
                                }
                            },
                            series: [
                                {
                                    label: Rates.props.dict.currentBuy,
                                    color:'#4ec42c',
                                    highlighter: {
                                        formatString: this.getTooltip('buy')
                                    }
                                },
                                {
                                    color: '#ffa101',
                                    label: Rates.props.dict.currentSell,
                                    highlighter: {
                                        formatString: this.getTooltip('sell')
                                    }
                                }
                            ]
                        });
                    }
                };

                if (Rates.state.data[code].plot) {
                    Rates.state.data[code].plot.destroy();
                }

                plot.data = plot.getPlotData();

                var newStateData = _.assign({}, Rates.state.data);

                if (plot.data) {
                    try {
                        newStateData[code].plot = plot.init();
                    } catch(e) {
                        Rates.utils.log('warn', 'couldn\'t build the plot for code %s', code);
                        newStateData[code].plot = null;
                    }
                } else {
                    Rates.utils.log('warn', 'no data to build the plot for code %s', code);
                    newStateData[code].plot = null;
                }

                Rates.setState({
                    data: newStateData
                });
            });
        }
    }
}